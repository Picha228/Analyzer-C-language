/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 3 "src/x-grammar.y"

  #include <stdio.h>
  #include <string.h>
  #include <assert.h>

  #include "x-lexer.h"
  
  #define MAX_NAME 	32
  #define MAX_COUNT 64
  #define YYDEBUG 1

  /* Это глобальные переменные */
  int flag_default = 0;
  int flag_loop = 0;
  
  int flag_struct = 0;
  int flag_enum = 0;
  int flag_union = 0;
  int flag_local_var = 0;
  
  char struct_construct[MAX_COUNT][MAX_NAME] = { 0 };
  int count_struct = 0;
  char union_construct[MAX_COUNT][MAX_NAME] = { 0 };
  int count_union = 0;
  
  char global_vars[MAX_COUNT][MAX_NAME] = { 0 };
  int count_global_vars = 0;  
  char local_vars[MAX_COUNT][MAX_NAME] = { 0 };
  int count_local_vars = 0;  

  /* Это сигнатуры необходимых bison'у функций */
  int yylex (void);
  void yyerror (char const * s);

  /* Здесь сигнатуры наших функций */
  static void printTerminal(const char * tokName);
  static void printNonTerminal(const char * tokName);
  
  void checkNewDeclaration(const char * identificator);
  void controlDeclaratedVariables(const char * identificator);
  void checkVariables(char variables[MAX_COUNT][MAX_NAME], int* count, const char * identificator);
  void free_local_vars();
  
  void newConstructionNameCheck(const char * identificator);
  void controlConstructionName(const char * identificator);

#line 118 "gen/x-grammar.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

#include "x-grammar.h"
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_TOK_IF = 3,                     /* TOK_IF  */
  YYSYMBOL_TOK_ELIF = 4,                   /* TOK_ELIF  */
  YYSYMBOL_TOK_ELSE = 5,                   /* TOK_ELSE  */
  YYSYMBOL_TOK_FOR = 6,                    /* TOK_FOR  */
  YYSYMBOL_TOK_BREAK = 7,                  /* TOK_BREAK  */
  YYSYMBOL_TOK_CONTINUE = 8,               /* TOK_CONTINUE  */
  YYSYMBOL_TOK_RET = 9,                    /* TOK_RET  */
  YYSYMBOL_TOK_TYPE_CHAR = 10,             /* TOK_TYPE_CHAR  */
  YYSYMBOL_TOK_TYPE_FLOAT = 11,            /* TOK_TYPE_FLOAT  */
  YYSYMBOL_TOK_TYPE_VOID = 12,             /* TOK_TYPE_VOID  */
  YYSYMBOL_TOK_TYPE_INT = 13,              /* TOK_TYPE_INT  */
  YYSYMBOL_TOK_TYPE_STATIC = 14,           /* TOK_TYPE_STATIC  */
  YYSYMBOL_TOK_TYPE_CONST = 15,            /* TOK_TYPE_CONST  */
  YYSYMBOL_TOK_TYPE_FILE = 16,             /* TOK_TYPE_FILE  */
  YYSYMBOL_TOK_TYPE__Bool = 17,            /* TOK_TYPE__Bool  */
  YYSYMBOL_TOK_TYPE_size_t = 18,           /* TOK_TYPE_size_t  */
  YYSYMBOL_TOK_CHAR = 19,                  /* TOK_CHAR  */
  YYSYMBOL_TOK_INT = 20,                   /* TOK_INT  */
  YYSYMBOL_TOK_FLOAT = 21,                 /* TOK_FLOAT  */
  YYSYMBOL_TOK_HEX_NUMBER = 22,            /* TOK_HEX_NUMBER  */
  YYSYMBOL_TOK_LOGIC = 23,                 /* TOK_LOGIC  */
  YYSYMBOL_TOK_COMPARE = 24,               /* TOK_COMPARE  */
  YYSYMBOL_TOK_SHIFT_OP = 25,              /* TOK_SHIFT_OP  */
  YYSYMBOL_TOK_BIT_OP = 26,                /* TOK_BIT_OP  */
  YYSYMBOL_TOK_INC_DEC = 27,               /* TOK_INC_DEC  */
  YYSYMBOL_TOK_PRE_ASSIGN_OP = 28,         /* TOK_PRE_ASSIGN_OP  */
  YYSYMBOL_TOK_EXTERN = 29,                /* TOK_EXTERN  */
  YYSYMBOL_TOK_INCLUDE = 30,               /* TOK_INCLUDE  */
  YYSYMBOL_TOK_DEFINE = 31,                /* TOK_DEFINE  */
  YYSYMBOL_TOK_STRING_DEFINE = 32,         /* TOK_STRING_DEFINE  */
  YYSYMBOL_TOK_STRING = 33,                /* TOK_STRING  */
  YYSYMBOL_TOK_STRING_INCLUDE = 34,        /* TOK_STRING_INCLUDE  */
  YYSYMBOL_TOK_WHILE = 35,                 /* TOK_WHILE  */
  YYSYMBOL_TOK_DO = 36,                    /* TOK_DO  */
  YYSYMBOL_TOK_ENUM = 37,                  /* TOK_ENUM  */
  YYSYMBOL_TOK_UNION = 38,                 /* TOK_UNION  */
  YYSYMBOL_TOK_STRUCT = 39,                /* TOK_STRUCT  */
  YYSYMBOL_TOK_SWITCH = 40,                /* TOK_SWITCH  */
  YYSYMBOL_TOK_CASE = 41,                  /* TOK_CASE  */
  YYSYMBOL_TOK_DEFAULT = 42,               /* TOK_DEFAULT  */
  YYSYMBOL_TOK_ERROR = 43,                 /* TOK_ERROR  */
  YYSYMBOL_TOK_DOT = 44,                   /* TOK_DOT  */
  YYSYMBOL_TOK_NULL = 45,                  /* TOK_NULL  */
  YYSYMBOL_TOK_SIZEOF = 46,                /* TOK_SIZEOF  */
  YYSYMBOL_TOK_IDENT = 47,                 /* TOK_IDENT  */
  YYSYMBOL_48_ = 48,                       /* '&'  */
  YYSYMBOL_49_ = 49,                       /* '-'  */
  YYSYMBOL_50_ = 50,                       /* '+'  */
  YYSYMBOL_51_ = 51,                       /* '*'  */
  YYSYMBOL_52_ = 52,                       /* '/'  */
  YYSYMBOL_53_ = 53,                       /* '%'  */
  YYSYMBOL_TOK_UMIN = 54,                  /* TOK_UMIN  */
  YYSYMBOL_TOK_NOT = 55,                   /* TOK_NOT  */
  YYSYMBOL_56_ = 56,                       /* '('  */
  YYSYMBOL_57_ = 57,                       /* ')'  */
  YYSYMBOL_58_ = 58,                       /* ';'  */
  YYSYMBOL_59_ = 59,                       /* '{'  */
  YYSYMBOL_60_ = 60,                       /* '}'  */
  YYSYMBOL_61_ = 61,                       /* '='  */
  YYSYMBOL_62_ = 62,                       /* ','  */
  YYSYMBOL_63_ = 63,                       /* '?'  */
  YYSYMBOL_64_ = 64,                       /* ':'  */
  YYSYMBOL_65_ = 65,                       /* '!'  */
  YYSYMBOL_66_ = 66,                       /* '['  */
  YYSYMBOL_67_ = 67,                       /* ']'  */
  YYSYMBOL_YYACCEPT = 68,                  /* $accept  */
  YYSYMBOL_program = 69,                   /* program  */
  YYSYMBOL_input = 70,                     /* input  */
  YYSYMBOL_union = 71,                     /* union  */
  YYSYMBOL_union_tok = 72,                 /* union_tok  */
  YYSYMBOL_union_args = 73,                /* union_args  */
  YYSYMBOL_struct = 74,                    /* struct  */
  YYSYMBOL_struct_tok = 75,                /* struct_tok  */
  YYSYMBOL_struct_args = 76,               /* struct_args  */
  YYSYMBOL_enumeration = 77,               /* enumeration  */
  YYSYMBOL_enum_tok = 78,                  /* enum_tok  */
  YYSYMBOL_enum_args = 79,                 /* enum_args  */
  YYSYMBOL_global_var_decl = 80,           /* global_var_decl  */
  YYSYMBOL_include = 81,                   /* include  */
  YYSYMBOL_define = 82,                    /* define  */
  YYSYMBOL_func_def = 83,                  /* func_def  */
  YYSYMBOL_func_sign = 84,                 /* func_sign  */
  YYSYMBOL_sign_arg_cons = 85,             /* sign_arg_cons  */
  YYSYMBOL_sign_arg_list = 86,             /* sign_arg_list  */
  YYSYMBOL_func_body = 87,                 /* func_body  */
  YYSYMBOL_statement = 88,                 /* statement  */
  YYSYMBOL_switch_case = 89,               /* switch_case  */
  YYSYMBOL_switch_token = 90,              /* switch_token  */
  YYSYMBOL_switch_body = 91,               /* switch_body  */
  YYSYMBOL_case_body = 92,                 /* case_body  */
  YYSYMBOL_single_statement = 93,          /* single_statement  */
  YYSYMBOL_decl_statement = 94,            /* decl_statement  */
  YYSYMBOL_decl_list = 95,                 /* decl_list  */
  YYSYMBOL_struct_list_init = 96,          /* struct_list_init  */
  YYSYMBOL_if_statement = 97,              /* if_statement  */
  YYSYMBOL_if_statement_head = 98,         /* if_statement_head  */
  YYSYMBOL_elif_statement = 99,            /* elif_statement  */
  YYSYMBOL_do_while_statement = 100,       /* do_while_statement  */
  YYSYMBOL_do_token = 101,                 /* do_token  */
  YYSYMBOL_while_statement = 102,          /* while_statement  */
  YYSYMBOL_while_token = 103,              /* while_token  */
  YYSYMBOL_for_statement = 104,            /* for_statement  */
  YYSYMBOL_for_token = 105,                /* for_token  */
  YYSYMBOL_loop_expr_1 = 106,              /* loop_expr_1  */
  YYSYMBOL_loop_expr_2 = 107,              /* loop_expr_2  */
  YYSYMBOL_loop_expr_3 = 108,              /* loop_expr_3  */
  YYSYMBOL_call_expr = 109,                /* call_expr  */
  YYSYMBOL_return_expr = 110,              /* return_expr  */
  YYSYMBOL_return_expr_tail = 111,         /* return_expr_tail  */
  YYSYMBOL_assign_expr = 112,              /* assign_expr  */
  YYSYMBOL_arg_cons = 113,                 /* arg_cons  */
  YYSYMBOL_expr = 114,                     /* expr  */
  YYSYMBOL_array_list = 115,               /* array_list  */
  YYSYMBOL_type_token = 116,               /* type_token  */
  YYSYMBOL_ident_ref_modifier = 117,       /* ident_ref_modifier  */
  YYSYMBOL_arr_index_token = 118,          /* arr_index_token  */
  YYSYMBOL_arr_decl_token = 119,           /* arr_decl_token  */
  YYSYMBOL_const_token = 120,              /* const_token  */
  YYSYMBOL_empty_rule = 121                /* empty_rule  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_int16 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
             && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE) \
             + YYSIZEOF (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  64
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   2431

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  68
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  54
/* YYNRULES -- Number of rules.  */
#define YYNRULES  223
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  528

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   304


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    65,     2,     2,     2,    53,    48,     2,
      56,    57,    51,    50,    62,    49,     2,    52,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    64,    58,
       2,    61,     2,    63,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    66,     2,    67,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,    59,     2,    60,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    54,    55
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    86,    86,    91,    92,    93,    94,    95,    96,    97,
      98,    99,   106,   110,   114,   115,   116,   117,   122,   126,
     130,   131,   132,   133,   138,   142,   146,   147,   148,   149,
     150,   155,   156,   161,   162,   167,   168,   169,   172,   173,
     174,   179,   181,   182,   183,   184,   185,   186,   191,   192,
     197,   199,   201,   203,   205,   207,   209,   211,   213,   215,
     217,   218,   219,   220,   221,   227,   228,   233,   234,   235,
     236,   237,   238,   243,   247,   251,   252,   253,   257,   258,
     263,   264,   265,   266,   267,   268,   269,   270,   275,   277,
     278,   279,   281,   283,   284,   286,   287,   288,   290,   291,
     292,   297,   298,   299,   300,   301,   302,   303,   304,   305,
     306,   307,   308,   309,   314,   315,   316,   321,   322,   323,
     328,   330,   331,   336,   337,   338,   343,   347,   352,   354,
     356,   357,   363,   368,   370,   374,   379,   380,   381,   386,
     387,   392,   393,   398,   403,   408,   409,   415,   416,   417,
     419,   420,   421,   423,   426,   428,   430,   432,   439,   440,
     441,   446,   448,   451,   453,   455,   457,   459,   461,   463,
     465,   467,   469,   471,   473,   475,   477,   479,   481,   483,
     485,   487,   490,   492,   494,   496,   498,   500,   502,   504,
     506,   508,   510,   512,   516,   518,   520,   524,   525,   531,
     532,   533,   534,   535,   536,   537,   538,   539,   540,   541,
     542,   543,   544,   549,   550,   555,   556,   561,   562,   567,
     568,   569,   570,   572
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "TOK_IF", "TOK_ELIF",
  "TOK_ELSE", "TOK_FOR", "TOK_BREAK", "TOK_CONTINUE", "TOK_RET",
  "TOK_TYPE_CHAR", "TOK_TYPE_FLOAT", "TOK_TYPE_VOID", "TOK_TYPE_INT",
  "TOK_TYPE_STATIC", "TOK_TYPE_CONST", "TOK_TYPE_FILE", "TOK_TYPE__Bool",
  "TOK_TYPE_size_t", "TOK_CHAR", "TOK_INT", "TOK_FLOAT", "TOK_HEX_NUMBER",
  "TOK_LOGIC", "TOK_COMPARE", "TOK_SHIFT_OP", "TOK_BIT_OP", "TOK_INC_DEC",
  "TOK_PRE_ASSIGN_OP", "TOK_EXTERN", "TOK_INCLUDE", "TOK_DEFINE",
  "TOK_STRING_DEFINE", "TOK_STRING", "TOK_STRING_INCLUDE", "TOK_WHILE",
  "TOK_DO", "TOK_ENUM", "TOK_UNION", "TOK_STRUCT", "TOK_SWITCH",
  "TOK_CASE", "TOK_DEFAULT", "TOK_ERROR", "TOK_DOT", "TOK_NULL",
  "TOK_SIZEOF", "TOK_IDENT", "'&'", "'-'", "'+'", "'*'", "'/'", "'%'",
  "TOK_UMIN", "TOK_NOT", "'('", "')'", "';'", "'{'", "'}'", "'='", "','",
  "'?'", "':'", "'!'", "'['", "']'", "$accept", "program", "input",
  "union", "union_tok", "union_args", "struct", "struct_tok",
  "struct_args", "enumeration", "enum_tok", "enum_args", "global_var_decl",
  "include", "define", "func_def", "func_sign", "sign_arg_cons",
  "sign_arg_list", "func_body", "statement", "switch_case", "switch_token",
  "switch_body", "case_body", "single_statement", "decl_statement",
  "decl_list", "struct_list_init", "if_statement", "if_statement_head",
  "elif_statement", "do_while_statement", "do_token", "while_statement",
  "while_token", "for_statement", "for_token", "loop_expr_1",
  "loop_expr_2", "loop_expr_3", "call_expr", "return_expr",
  "return_expr_tail", "assign_expr", "arg_cons", "expr", "array_list",
  "type_token", "ident_ref_modifier", "arr_index_token", "arr_decl_token",
  "const_token", "empty_rule", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-483)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-206)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
    1595,   -41,   -41,   138,   -41,   414,   522,   -41,   -41,   -41,
    1416,   225,     5,  -483,  -483,  -483,    24,    42,  1595,   103,
    -483,  1595,    84,  1595,   105,  1595,   110,  1595,  1595,  1595,
    1595,   180,   116,    31,   -41,  -483,  -483,  -483,    24,  -483,
    -483,   -41,   -41,   -41,   -41,   -41,   -41,   -41,  -483,  -483,
    -483,   -41,  -483,   178,   185,   137,   187,  -483,  -483,  1618,
     131,  -483,    24,  -483,  -483,  -483,    28,  -483,    71,  -483,
     159,  -483,  -483,  -483,  -483,  -483,  -483,   387,  -483,    55,
     154,   182,   205,  -483,  -483,  -483,  -483,  -483,  -483,  -483,
    -483,  -483,   -41,   -41,  -483,   136,  -483,  -483,  -483,  -483,
    1651,  -483,  -483,   214,   171,   -40,  1651,   -35,  1515,   324,
    1651,  -483,  -483,  2334,  -483,    75,  1675,  -483,   230,   115,
    -483,  1644,   242,  1539,   259,    38,   848,  -483,    24,  -483,
      58,   262,  1684,   222,   550,  -483,  -483,   -11,   247,  -483,
      24,   284,   314,    24,  1571,   -38,  1571,  1651,   334,  1651,
    1651,    -2,    32,   340,   -38,  -483,  1651,   150,  1884,   337,
     335,   344,   -38,  1651,  1651,  1651,  1651,  -483,  1651,  1651,
    1651,  1651,  1651,  1651,  1651,  1651,  -483,   -41,   -41,   271,
     -41,   361,  -483,   274,  1708,   363,   366,   336,   369,  -483,
     236,   373,   368,   376,  -483,   265,   268,   386,   379,  -483,
     384,  -483,  -483,  -483,  1651,  1651,  -483,  -483,  -483,   267,
    -483,  -483,  -483,   389,   388,  -483,  -483,   437,  -483,   390,
    -483,   396,  -483,   397,   398,  -483,   400,  2365,    24,   393,
     324,  1853,   189,   328,   778,   401,  -483,  1651,  -483,    24,
    -483,  -483,  1928,   415,  2334,    -8,   416,  1972,  -483,  1651,
    1651,   428,  -483,   430,  2003,  1651,  -483,  1651,  -483,   324,
     661,   706,   581,   241,    30,   241,   160,   160,   -26,   -26,
     -26,  2047,   434,   443,   435,   339,   445,   451,   438,  1708,
     444,  -483,   446,   -41,   449,    67,  1717,  -483,   -41,   452,
     126,  1750,  -483,   324,  -483,   273,   454,  1651,  -483,  2334,
    -483,   213,  1651,  -483,   455,  -483,  1651,  1459,   458,  1651,
     453,    22,  -483,  -483,  1783,  -483,   303,   305,   341,   262,
     324,  1853,  -483,  -483,  -483,  1651,  1651,     2,  -483,  1651,
    2334,  2334,   262,   460,  -483,  2078,    30,  -483,  1651,  1651,
    1708,   474,  1708,  -483,  1708,  1708,   475,  -483,  1644,   480,
     324,  1853,   494,  -483,  1539,   485,   324,  1853,    38,   324,
    -483,  -483,  2109,  2153,  -483,  1343,   908,   488,  2334,  -483,
    -483,   489,   491,  2334,  -483,  1853,    88,   324,  -483,   118,
     324,  1853,   487,  -483,  1816,  -483,   322,   504,  -483,   492,
    -483,  2334,  2334,  1651,  1651,  -483,  -483,   262,  1651,  2197,
    2228,  -483,  1708,  -483,  -483,  -483,   496,  -483,  1644,   148,
    -483,   498,  -483,  1539,   497,  -483,  -483,    38,   218,   499,
     983,   528,   258,  1651,  -483,  -483,  -483,   324,   505,  -483,
     324,   324,  1853,  1651,  -483,    88,    88,  2334,  2334,  -483,
    2259,  1651,  1651,  -483,  1644,  -483,    88,  1539,  -483,    88,
    -483,  -483,  -483,  1043,   307,  -483,   510,  -483,  -483,  1403,
     509,    88,   508,   513,  -483,  1853,  -483,  -483,  1651,  2334,
    2334,  -483,  -483,  -483,  -483,  1103,   519,  -483,  -483,   324,
     518,   525,  -483,  1651,  1163,  1651,  -483,    88,    88,  -483,
    2334,   582,  1651,   524,  1343,  -483,   532,   533,   536,  2334,
    -483,  -483,  -483,  -483,  2290,  1343,  1343,   307,  -483,   544,
    -483,   531,   548,   307,  -483,  -483,  -483,  -483,  1403,  -483,
    1043,  -483,  1223,  1283,  -483,  -483,   582,  -483
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,   223,   223,   223,   223,     0,     0,   223,   223,   223,
       0,     0,     0,    25,    13,    19,    91,     0,     0,     0,
       2,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       3,     0,     0,     0,   223,   201,   214,   203,     0,   205,
     199,   223,   223,   223,   223,   223,   223,   223,   210,   211,
     212,   223,    91,     0,     0,     0,     0,    34,    33,    37,
       0,    46,     0,    11,     1,     9,   223,    10,   223,     8,
       0,     5,     6,     7,     4,    39,   223,     0,    32,   223,
       0,     0,     0,   213,    44,   208,   209,   207,   202,   204,
     206,   200,   223,   223,    31,   223,   220,   219,   221,   165,
       0,   222,   171,     0,   172,     0,     0,     0,     0,     0,
       0,   170,   163,    35,   161,   223,     0,    48,     0,    63,
      47,   223,     0,   223,     0,   223,     0,    66,     0,    40,
       0,     0,     0,     0,     0,    41,    88,   223,     0,   113,
       0,     0,   218,     0,     0,   187,     0,     0,     0,   223,
       0,   175,   173,     0,   195,   162,     0,   172,     0,     0,
       0,   197,   196,     0,     0,     0,     0,   186,     0,     0,
       0,     0,     0,     0,     0,     0,   174,   223,   223,   223,
     223,     0,    49,    50,     0,     0,     0,     0,     0,    17,
     223,     0,     0,     0,    23,   223,   223,     0,     0,    30,
       0,   135,    84,    85,   223,     0,   132,   127,    74,   172,
      38,    65,    72,     0,     0,    80,    68,   117,    71,     0,
      70,     0,    69,     0,   170,    83,   163,     0,     0,     0,
     223,   223,   223,     0,     0,     0,    89,     0,    42,     0,
     217,    45,     0,     0,   152,   178,     0,   158,   160,     0,
       0,     0,   177,     0,     0,     0,   182,     0,   164,     0,
     193,   194,   183,   184,   151,   185,   189,   188,   190,   191,
     192,   147,   202,   204,    52,   223,   206,   200,    51,     0,
      61,    64,    55,   223,     0,     0,     0,    98,   223,     0,
       0,     0,    95,     0,    27,   223,     0,     0,   144,   145,
     146,   187,     0,    67,   223,   223,   223,   223,   186,     0,
       0,   197,   116,    90,     0,   101,   223,   223,     0,   216,
     223,   223,    43,   166,   168,     0,     0,   180,   143,   223,
     153,   150,   179,     0,   167,     0,   169,   198,     0,     0,
       0,    53,     0,    56,     0,     0,     0,    12,   223,     0,
       0,   223,     0,    18,   223,     0,   223,   223,   223,     0,
      29,    24,     0,     0,   223,   119,     0,     0,   139,   140,
     136,     0,   163,     0,   138,   223,   223,   223,   115,   223,
     223,   223,     0,   110,     0,   102,   223,     0,   215,     0,
      92,   156,   154,     0,     0,   159,   181,     0,     0,     0,
       0,    58,     0,    57,    62,    60,     0,    14,   223,     0,
     100,     0,    20,   223,     0,    97,    26,   223,   223,     0,
       0,     0,   223,   223,   112,    93,   114,   223,     0,   105,
     223,   223,   223,     0,   103,   223,   223,   157,   155,   176,
       0,     0,     0,    59,   223,    15,   223,   223,    21,   223,
      28,   122,   223,   223,   223,   118,     0,   131,   223,   130,
       0,   223,     0,     0,   106,   223,   104,    94,     0,   149,
     148,    16,    99,    22,    96,     0,     0,   121,   125,     0,
       0,     0,    77,   223,     0,   223,   108,   223,   223,   107,
      36,   223,     0,     0,   223,    73,     0,   128,     0,   141,
     142,   111,   109,   120,     0,   223,   223,   223,    79,     0,
     129,   223,   223,   223,    78,    76,   126,   223,   134,   223,
     223,    75,     0,     0,   124,   133,   223,   123
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -483,  -483,   441,  -483,    39,  -331,  -483,     4,  -343,  -483,
    -483,  -194,  -483,  -483,  -483,   534,  -483,   -25,  -169,  -198,
    -315,  -483,  -483,  -354,  -144,  -483,    65,   349,  -184,  -483,
    -483,  -482,  -483,  -483,  -483,   192,  -483,  -483,  -483,  -409,
    -483,   -27,  -483,  -483,    56,   285,   355,  -254,   140,   700,
     -23,   -71,   244,   -76
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
       0,    19,    20,    21,    53,   187,    23,    54,   192,    25,
      26,   198,    27,    28,    29,    30,    31,    61,   118,   126,
     211,   212,   213,   481,   507,   214,   215,   136,   378,   216,
     217,   477,   218,   219,   220,   221,   222,   223,   371,   367,
     498,   111,   225,   298,   112,   246,   227,   160,    56,    39,
     176,    82,   114,    36
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_int16 yytable[] =
{
     127,   167,   294,   139,    24,   337,   168,   152,   138,   503,
      34,   412,   155,    84,   460,   281,   153,   407,   168,   139,
     325,   156,    24,   175,   138,    24,   249,    24,   150,    24,
     393,    24,    24,    24,    24,   175,   131,   120,   524,    22,
     150,    96,    97,    98,   527,   189,   310,   194,   185,   199,
     235,   133,    59,   326,   135,   101,   137,    22,   150,   250,
      22,   139,    22,   394,    22,    32,    22,    22,    22,    22,
     448,   240,   137,   248,   496,    55,   251,   445,    79,    34,
      60,   151,    80,    32,   377,   196,    32,   121,    32,    62,
      32,   175,    32,    32,    32,    32,   150,    81,   150,   224,
     197,   360,   131,    64,   473,   228,   365,   366,   229,    80,
     343,    60,   280,   471,   139,   238,   132,   133,   241,   139,
     199,   134,    34,   337,    81,   348,    34,   191,   300,   252,
     123,    66,   -54,   150,   151,   131,   389,    96,    97,    98,
      33,     1,     2,   115,     4,     5,   116,     7,     8,     9,
     133,   101,    68,   515,   312,   139,   139,    70,    33,   521,
     186,    33,   183,    33,   416,    33,   420,    33,    33,    33,
      33,   401,   414,   403,    78,   404,   405,   184,   147,   506,
     427,    81,   226,   131,   354,    38,   151,   167,   117,    34,
     506,   506,   150,   426,   148,    94,   428,   132,   133,   147,
     119,   140,   134,   135,   168,   141,   149,   255,   446,   316,
     259,   172,   173,   174,   322,   148,   150,   130,   125,   199,
     453,   175,   327,   450,   459,    92,   150,   149,   127,   127,
     369,   374,    93,   443,    95,   312,   131,   150,    75,    76,
     139,   139,    77,   426,   312,   139,   462,   463,   159,   142,
     314,   133,   143,   248,   475,   150,   181,   168,    57,    58,
     484,   188,   349,   193,   163,   164,   165,   355,   167,   232,
     146,   -87,   189,   233,   175,   139,   451,   452,   194,   150,
     312,   139,   199,   131,   159,   168,   243,   182,   127,   190,
     170,   171,   172,   173,   174,   147,   388,   286,   133,   139,
     139,   312,   175,   312,   312,   139,   195,   150,   237,   396,
     139,   148,   131,   518,   520,   196,   457,   458,   274,   522,
     196,   523,   275,   149,   119,   -91,   291,   133,   150,   293,
     197,   239,   189,   150,   359,   197,   279,   194,   224,   224,
      81,   199,   127,    96,    97,    98,   127,   369,   479,   480,
     131,   312,   131,   161,   312,   312,   139,   101,   191,   139,
     139,   513,   514,   372,   382,   133,   384,   133,   189,   131,
     139,   194,   370,   139,   439,   317,   127,   478,   482,   318,
      81,   245,   127,   433,   133,   139,   341,   186,   386,   139,
      34,   253,   387,   224,   257,   258,   284,     1,     2,     3,
       4,     5,     6,     7,     8,     9,   259,   369,   278,   500,
     282,   139,   139,   283,   113,   478,   285,   191,   508,   119,
     288,   226,   226,   290,    41,    42,   224,    43,   289,   508,
     508,   482,   224,   295,   128,   127,   127,   482,    17,   296,
     297,   127,   304,   127,   478,   302,   303,   186,   224,   305,
     478,   191,   306,   307,   309,   145,   -81,   224,   -82,    63,
     320,   154,    65,   158,    67,   162,    69,   224,    71,    72,
      73,    74,   324,   328,   311,   332,   226,   333,   224,   224,
     119,  -201,   119,   186,   119,   119,   236,   231,   188,   234,
    -203,   224,  -205,   224,   193,   224,   224,   340,  -199,   158,
     342,   242,   244,   161,   247,   234,   344,   347,   345,   226,
     353,   254,   361,   376,   364,   226,   -86,   397,   260,   261,
     262,   263,   406,   264,   265,   266,   267,   268,   269,   270,
     271,   226,    44,    45,    46,    47,   402,   358,   408,   287,
     226,   411,   119,   413,   292,   422,   430,   423,   188,  -137,
     226,   435,   436,   193,   444,   379,   447,   449,   454,   299,
     301,   226,   226,   206,   379,   461,   483,   485,   487,    96,
      97,    98,    99,   488,   226,   492,   226,   100,   226,   226,
     313,   315,   494,   101,   188,   495,   476,   193,   505,   509,
     517,   510,   321,   511,   409,   102,   103,   104,   105,   106,
     311,   107,   516,   417,   330,   331,   144,   519,   167,   109,
     335,   129,   336,   456,   395,   110,     0,   142,     0,     0,
       0,   311,     0,   379,   311,   168,     0,     0,     0,     0,
     170,   171,   172,   173,   174,     0,     0,     0,     0,     0,
       0,   351,   175,     0,     0,     0,   357,   150,     0,     0,
       0,     0,   362,     0,     0,     0,     0,   363,     0,     0,
       0,   368,   373,     0,   375,   383,   385,     0,     0,   381,
     390,   379,     0,     0,   379,   311,     0,     0,     0,     0,
     391,   392,     0,     0,   247,   164,   165,     0,   167,     0,
       0,     0,     0,   399,   400,     0,     0,     0,     0,     0,
     410,    35,    37,     0,    40,   168,   415,    48,    49,    50,
     170,   171,   172,   173,   174,     0,     0,     0,     0,     0,
       0,     0,   175,   493,   424,   425,     0,   150,     0,     0,
     429,   165,     0,   167,    83,   434,     0,     0,     0,   432,
       0,    85,    86,    87,    88,    89,    90,    91,   437,   438,
     168,     0,     0,   440,     0,   170,   171,   172,   173,   174,
       0,     0,     0,     0,     0,     0,   122,   175,   124,   338,
       0,     0,   150,     0,     0,     0,     0,     0,   368,     0,
       0,   464,     0,     0,   466,   467,     0,     0,   465,     0,
       0,     0,   122,   124,     0,   472,   469,   470,   474,     0,
       0,   163,   164,   165,   166,   167,     0,     0,     0,     0,
     486,     0,     0,     0,   489,     0,     0,     0,     0,     0,
       0,     0,   168,   490,     0,     0,   169,   170,   171,   172,
     173,   174,     0,     0,     0,     0,   501,   502,   368,   175,
     499,     0,     0,     0,   150,   319,     0,   504,     0,     0,
       0,   200,     0,     0,   201,   202,   203,   204,     1,     2,
      51,     4,     5,     6,     7,     8,     9,    96,    97,    98,
      99,     0,     0,     0,     0,   205,     0,   272,   273,   276,
     277,   101,     0,   206,   207,     0,    14,    15,   208,     0,
       0,     0,     0,   102,   103,   209,   105,   106,     0,   107,
       0,     0,     0,     0,   144,     0,     0,   109,   210,     0,
       0,   200,     0,   110,   201,   202,   203,   204,     1,     2,
      51,     4,     5,     6,     7,     8,     9,    96,    97,    98,
      99,     0,     0,     0,     0,   205,     0,     0,     0,     0,
       0,   101,     0,   206,   207,     0,    14,    15,   208,     0,
       0,     0,     0,   102,   103,   209,   105,   106,     0,   107,
       0,     0,     0,     0,   144,     0,     0,   109,   421,     0,
       0,     0,     0,   110,     0,    83,     0,     0,     0,     0,
       0,     0,     0,   346,     0,     0,   200,     0,   352,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,   455,     0,     0,   200,   476,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,     0,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,   491,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,   497,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,   525,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,   526,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     0,     0,     0,     0,
     205,     0,     0,     0,     0,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,   105,   106,     0,   107,     0,     0,     0,     0,   144,
       0,     0,   109,     0,     0,     0,   200,     0,   110,   201,
     202,   203,   204,     1,     2,    51,     4,     5,     6,     7,
       8,     9,    96,    97,    98,    99,     1,     2,    51,     4,
       5,     6,     7,     8,     9,     0,   101,     0,   206,   207,
       0,    14,    15,   208,     0,     0,     0,     0,   102,   103,
     209,     0,     0,     0,    14,    15,     0,     0,     0,     0,
       0,     0,   109,    52,     0,     0,     0,     0,   110,     1,
       2,    51,     4,     5,     6,     7,     8,     9,    96,    97,
      98,    99,     0,     0,     0,     0,   100,     0,     0,     0,
       0,     0,   101,     0,     0,     0,     0,    14,    15,     0,
       0,     0,     0,     0,   102,   103,   209,   105,   106,     0,
     107,     0,     0,     0,     0,   144,     0,     0,   109,     0,
       0,     0,     0,     0,   110,     1,     2,    51,     4,     5,
       6,     7,     8,     9,    96,    97,    98,    99,     0,     0,
       0,     0,   100,     0,     0,     0,     0,     0,   101,     1,
       2,    51,     4,     5,     6,     7,     8,     9,     0,     0,
     102,   103,   157,   105,   106,     0,   107,     0,     0,     0,
       0,   144,     0,     0,   109,     0,     0,     0,    15,     0,
     110,     1,     2,    51,     4,     5,     6,     7,     8,     9,
      96,    97,    98,    99,     0,     0,     0,     0,   100,     0,
       0,     0,     0,     0,   101,     1,     2,     3,     4,     5,
       6,     7,     8,     9,     0,     0,   102,   103,   104,   105,
     106,     0,   107,     0,    10,    11,    12,   144,     0,     0,
     109,     0,    13,    14,    15,     0,   110,    96,    97,    98,
      99,     0,    16,     0,     0,   100,    17,     0,     0,     0,
       0,   101,     0,    18,     1,     2,    51,     4,     5,     6,
       7,     8,     9,   102,   103,   104,   105,   106,     0,   107,
      96,    97,    98,    99,   108,     0,     0,   109,   100,     0,
       0,     0,    14,   110,   101,   177,   178,   179,   180,     5,
       6,     7,     8,     9,     0,     0,   102,   103,   104,   105,
     106,     0,   107,    96,    97,    98,    99,   144,     0,     0,
     109,   100,     0,     0,     0,     0,   110,   101,     1,     2,
     115,     4,     5,   116,     7,     8,     9,     0,     0,   102,
     103,   104,   105,   106,     0,   107,    96,    97,    98,    99,
     144,     0,     0,   230,   100,     0,     0,     0,     0,   110,
     101,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   102,   103,   104,   105,   106,     0,   107,    96,
      97,    98,    99,   144,     0,     0,   350,   100,     0,     0,
       0,     0,   110,   101,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   102,   103,   104,   105,   106,
       0,   107,    96,    97,    98,    99,   144,     0,     0,   356,
     100,     0,     0,     0,     0,   110,   101,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   102,   103,
     104,   105,   106,     0,   107,    96,    97,    98,    99,   144,
       0,     0,   380,   100,     0,     0,     0,     0,   110,   101,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   102,   103,   104,   105,   106,     0,   107,     0,     0,
       0,     0,   144,     0,     0,   431,   163,   164,   165,   166,
     167,   110,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   168,     0,     0,
     131,   169,   170,   171,   172,   173,   174,   163,   164,   165,
     166,   167,     0,     0,   175,   133,     0,     0,     0,   150,
       0,     0,     0,     0,     0,     0,     0,     0,   168,     0,
       0,     0,   169,   170,   171,   172,   173,   174,     0,     0,
       0,   256,     0,     0,     0,   175,     0,     0,     0,     0,
     150,   163,   164,   165,   166,   167,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   168,     0,     0,     0,   169,   170,   171,   172,
     173,   174,     0,     0,     0,   323,     0,     0,     0,   175,
       0,     0,     0,     0,   150,   163,   164,   165,   166,   167,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   168,     0,     0,     0,
     169,   170,   171,   172,   173,   174,   163,   164,   165,   166,
     167,     0,     0,   175,   329,     0,     0,     0,   150,     0,
       0,     0,     0,     0,     0,     0,     0,   168,     0,     0,
       0,   169,   170,   171,   172,   173,   174,     0,     0,     0,
     334,     0,     0,     0,   175,     0,     0,     0,     0,   150,
     163,   164,   165,   166,   167,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   168,     0,     0,     0,   169,   170,   171,   172,   173,
     174,   163,   164,   165,   166,   167,     0,     0,   175,     0,
     339,     0,     0,   150,     0,     0,     0,     0,     0,     0,
       0,     0,   168,     0,     0,     0,   169,   170,   171,   172,
     173,   174,   163,   164,   165,   166,   167,     0,     0,   175,
       0,   398,     0,     0,   150,     0,     0,     0,     0,     0,
       0,     0,     0,   168,     0,     0,     0,   169,   170,   171,
     172,   173,   174,     0,     0,     0,   418,     0,     0,     0,
     175,     0,     0,     0,     0,   150,   163,   164,   165,   166,
     167,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   168,     0,     0,
       0,   169,   170,   171,   172,   173,   174,     0,     0,     0,
     419,     0,     0,     0,   175,     0,     0,     0,     0,   150,
     163,   164,   165,   166,   167,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   168,     0,     0,     0,   169,   170,   171,   172,   173,
     174,   163,   164,   165,   166,   167,     0,     0,   175,     0,
       0,   441,     0,   150,     0,     0,     0,     0,     0,     0,
       0,     0,   168,     0,     0,     0,   169,   170,   171,   172,
     173,   174,   163,   164,   165,   166,   167,     0,     0,   175,
       0,     0,   442,     0,   150,     0,     0,     0,     0,     0,
       0,     0,     0,   168,     0,     0,     0,   169,   170,   171,
     172,   173,   174,   163,   164,   165,   166,   167,     0,     0,
     175,     0,     0,   468,     0,   150,     0,     0,     0,     0,
       0,     0,     0,     0,   168,     0,     0,     0,   169,   170,
     171,   172,   173,   174,     0,     0,     0,   512,     0,     0,
       0,   175,     0,     0,     0,     0,   150,   163,   164,   165,
     166,   167,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   168,     0,
       0,     0,   169,   170,   171,   172,   173,   174,   163,   164,
     165,   166,   308,     0,     0,   175,     0,     0,     0,     0,
     150,     0,     0,     0,     0,     0,     0,     0,     0,   168,
       0,     0,     0,   169,   170,   171,   172,   173,   174,     0,
       0,     0,     0,     0,     0,     0,   175,     0,     0,     0,
       0,   150
};

static const yytype_int16 yycheck[] =
{
      76,    27,   196,    79,     0,   259,    44,    47,    79,   491,
      51,   354,    47,    38,   423,   184,    56,   348,    44,    95,
      28,    56,    18,    61,    95,    21,    28,    23,    66,    25,
      28,    27,    28,    29,    30,    61,    47,    62,   520,     0,
      66,    19,    20,    21,   526,   121,   230,   123,   119,   125,
      61,    62,    47,    61,    79,    33,    79,    18,    66,    61,
      21,   137,    23,    61,    25,     0,    27,    28,    29,    30,
     413,   142,    95,   149,   483,    10,    44,   408,    47,    51,
      56,   104,    51,    18,    62,    47,    21,    59,    23,    47,
      25,    61,    27,    28,    29,    30,    66,    66,    66,   126,
      62,   295,    47,     0,   447,    47,   304,   305,   131,    51,
     279,    56,   183,   444,   190,   140,    61,    62,   143,   195,
     196,    66,    51,   377,    66,    58,    51,   123,   204,   152,
      59,    47,    57,    66,   157,    47,   320,    19,    20,    21,
       0,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      62,    33,    47,   507,   230,   231,   232,    47,    18,   513,
     121,    21,    47,    23,   358,    25,   364,    27,    28,    29,
      30,   340,   356,   342,    58,   344,   345,    62,    28,   494,
      62,    66,   126,    47,    58,    47,   209,    27,    57,    51,
     505,   506,    66,   377,    44,    58,   380,    61,    62,    28,
      60,    47,    66,   228,    44,    51,    56,    57,    60,   232,
      62,    51,    52,    53,   239,    44,    66,    77,    59,   295,
     418,    61,   245,   417,   422,    47,    66,    56,   304,   305,
     306,   307,    47,   402,    47,   311,    47,    66,    58,    59,
     316,   317,    62,   427,   320,   321,   430,   431,   108,    67,
      61,    62,    47,   329,   452,    66,   116,    44,    33,    34,
     458,   121,   285,   123,    23,    24,    25,   290,    27,    47,
      56,    58,   348,    51,    61,   351,    58,    59,   354,    66,
     356,   357,   358,    47,   144,    44,   146,    57,   364,    47,
      49,    50,    51,    52,    53,    28,   319,    61,    62,   375,
     376,   377,    61,   379,   380,   381,    47,    66,    61,   332,
     386,    44,    47,   511,   512,    47,    58,    59,    47,   517,
      47,   519,    51,    56,   184,    58,    61,    62,    66,    61,
      62,    47,   408,    66,    61,    62,    62,   413,   365,   366,
      66,   417,   418,    19,    20,    21,   422,   423,    41,    42,
      47,   427,    47,   109,   430,   431,   432,    33,   354,   435,
     436,   505,   506,   307,    61,    62,    61,    62,   444,    47,
     446,   447,   307,   449,   397,    47,   452,   453,   454,    51,
      66,    47,   458,    61,    62,   461,    47,   348,    47,   465,
      51,    51,    51,   420,    57,    60,    60,    10,    11,    12,
      13,    14,    15,    16,    17,    18,    62,   483,    47,   485,
      47,   487,   488,    47,    59,   491,    47,   413,   494,   279,
      47,   365,   366,    47,    10,    11,   453,    13,    60,   505,
     506,   507,   459,    47,    47,   511,   512,   513,    51,    60,
      56,   517,     5,   519,   520,    56,    58,   408,   475,    59,
     526,   447,    56,    56,    61,   100,    58,   484,    58,    18,
      59,   106,    21,   108,    23,   110,    25,   494,    27,    28,
      29,    30,    57,    57,   230,    47,   420,    47,   505,   506,
     340,    47,   342,   444,   344,   345,   137,   132,   348,   134,
      47,   518,    47,   520,   354,   522,   523,    62,    47,   144,
      62,   146,   147,   259,   149,   150,    62,    58,    62,   453,
      58,   156,    58,    60,    59,   459,    58,    57,   163,   164,
     165,   166,    47,   168,   169,   170,   171,   172,   173,   174,
     175,   475,    10,    11,    12,    13,    62,   293,    58,   190,
     484,    47,   402,    58,   195,    57,    59,    58,   408,    58,
     494,    47,    60,   413,    58,   311,    58,    60,    59,   204,
     205,   505,   506,    35,   320,    60,    56,    58,    60,    19,
      20,    21,    22,    60,   518,    56,   520,    27,   522,   523,
     231,   232,    64,    33,   444,    60,     4,   447,    64,    57,
      59,    58,   237,    57,   350,    45,    46,    47,    48,    49,
     356,    51,    58,   359,   249,   250,    56,    59,    27,    59,
     255,    77,   257,   421,   329,    65,    -1,    67,    -1,    -1,
      -1,   377,    -1,   379,   380,    44,    -1,    -1,    -1,    -1,
      49,    50,    51,    52,    53,    -1,    -1,    -1,    -1,    -1,
      -1,   286,    61,    -1,    -1,    -1,   291,    66,    -1,    -1,
      -1,    -1,   297,    -1,    -1,    -1,    -1,   302,    -1,    -1,
      -1,   306,   307,    -1,   309,   316,   317,    -1,    -1,   314,
     321,   427,    -1,    -1,   430,   431,    -1,    -1,    -1,    -1,
     325,   326,    -1,    -1,   329,    24,    25,    -1,    27,    -1,
      -1,    -1,    -1,   338,   339,    -1,    -1,    -1,    -1,    -1,
     351,     1,     2,    -1,     4,    44,   357,     7,     8,     9,
      49,    50,    51,    52,    53,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    61,   479,   375,   376,    -1,    66,    -1,    -1,
     381,    25,    -1,    27,    34,   386,    -1,    -1,    -1,   384,
      -1,    41,    42,    43,    44,    45,    46,    47,   393,   394,
      44,    -1,    -1,   398,    -1,    49,    50,    51,    52,    53,
      -1,    -1,    -1,    -1,    -1,    -1,    66,    61,    68,    63,
      -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,   423,    -1,
      -1,   432,    -1,    -1,   435,   436,    -1,    -1,   433,    -1,
      -1,    -1,    92,    93,    -1,   446,   441,   442,   449,    -1,
      -1,    23,    24,    25,    26,    27,    -1,    -1,    -1,    -1,
     461,    -1,    -1,    -1,   465,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    44,   468,    -1,    -1,    48,    49,    50,    51,
      52,    53,    -1,    -1,    -1,    -1,   487,   488,   483,    61,
     485,    -1,    -1,    -1,    66,    67,    -1,   492,    -1,    -1,
      -1,     3,    -1,    -1,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    -1,    -1,    -1,    -1,    27,    -1,   177,   178,   179,
     180,    33,    -1,    35,    36,    -1,    38,    39,    40,    -1,
      -1,    -1,    -1,    45,    46,    47,    48,    49,    -1,    51,
      -1,    -1,    -1,    -1,    56,    -1,    -1,    59,    60,    -1,
      -1,     3,    -1,    65,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    -1,    -1,    -1,    -1,    27,    -1,    -1,    -1,    -1,
      -1,    33,    -1,    35,    36,    -1,    38,    39,    40,    -1,
      -1,    -1,    -1,    45,    46,    47,    48,    49,    -1,    51,
      -1,    -1,    -1,    -1,    56,    -1,    -1,    59,    60,    -1,
      -1,    -1,    -1,    65,    -1,   275,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,   283,    -1,    -1,     3,    -1,   288,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,     3,     4,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    -1,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    60,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    -1,    -1,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    -1,    -1,    -1,    -1,    56,
      -1,    -1,    59,    -1,    -1,    -1,     3,    -1,    65,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      17,    18,    19,    20,    21,    22,    10,    11,    12,    13,
      14,    15,    16,    17,    18,    -1,    33,    -1,    35,    36,
      -1,    38,    39,    40,    -1,    -1,    -1,    -1,    45,    46,
      47,    -1,    -1,    -1,    38,    39,    -1,    -1,    -1,    -1,
      -1,    -1,    59,    47,    -1,    -1,    -1,    -1,    65,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    -1,    -1,    -1,    -1,    27,    -1,    -1,    -1,
      -1,    -1,    33,    -1,    -1,    -1,    -1,    38,    39,    -1,
      -1,    -1,    -1,    -1,    45,    46,    47,    48,    49,    -1,
      51,    -1,    -1,    -1,    -1,    56,    -1,    -1,    59,    -1,
      -1,    -1,    -1,    -1,    65,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    -1,    -1,
      -1,    -1,    27,    -1,    -1,    -1,    -1,    -1,    33,    10,
      11,    12,    13,    14,    15,    16,    17,    18,    -1,    -1,
      45,    46,    47,    48,    49,    -1,    51,    -1,    -1,    -1,
      -1,    56,    -1,    -1,    59,    -1,    -1,    -1,    39,    -1,
      65,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      19,    20,    21,    22,    -1,    -1,    -1,    -1,    27,    -1,
      -1,    -1,    -1,    -1,    33,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    -1,    -1,    45,    46,    47,    48,
      49,    -1,    51,    -1,    29,    30,    31,    56,    -1,    -1,
      59,    -1,    37,    38,    39,    -1,    65,    19,    20,    21,
      22,    -1,    47,    -1,    -1,    27,    51,    -1,    -1,    -1,
      -1,    33,    -1,    58,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    45,    46,    47,    48,    49,    -1,    51,
      19,    20,    21,    22,    56,    -1,    -1,    59,    27,    -1,
      -1,    -1,    38,    65,    33,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    -1,    -1,    45,    46,    47,    48,
      49,    -1,    51,    19,    20,    21,    22,    56,    -1,    -1,
      59,    27,    -1,    -1,    -1,    -1,    65,    33,    10,    11,
      12,    13,    14,    15,    16,    17,    18,    -1,    -1,    45,
      46,    47,    48,    49,    -1,    51,    19,    20,    21,    22,
      56,    -1,    -1,    59,    27,    -1,    -1,    -1,    -1,    65,
      33,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    45,    46,    47,    48,    49,    -1,    51,    19,
      20,    21,    22,    56,    -1,    -1,    59,    27,    -1,    -1,
      -1,    -1,    65,    33,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    45,    46,    47,    48,    49,
      -1,    51,    19,    20,    21,    22,    56,    -1,    -1,    59,
      27,    -1,    -1,    -1,    -1,    65,    33,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    45,    46,
      47,    48,    49,    -1,    51,    19,    20,    21,    22,    56,
      -1,    -1,    59,    27,    -1,    -1,    -1,    -1,    65,    33,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    45,    46,    47,    48,    49,    -1,    51,    -1,    -1,
      -1,    -1,    56,    -1,    -1,    59,    23,    24,    25,    26,
      27,    65,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,    -1,
      47,    48,    49,    50,    51,    52,    53,    23,    24,    25,
      26,    27,    -1,    -1,    61,    62,    -1,    -1,    -1,    66,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    -1,    -1,
      -1,    57,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      66,    23,    24,    25,    26,    27,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    44,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    -1,    -1,    -1,    57,    -1,    -1,    -1,    61,
      -1,    -1,    -1,    -1,    66,    23,    24,    25,    26,    27,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,    -1,    -1,
      48,    49,    50,    51,    52,    53,    23,    24,    25,    26,
      27,    -1,    -1,    61,    62,    -1,    -1,    -1,    66,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    -1,    -1,    -1,
      57,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    66,
      23,    24,    25,    26,    27,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    44,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    23,    24,    25,    26,    27,    -1,    -1,    61,    -1,
      63,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    44,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    23,    24,    25,    26,    27,    -1,    -1,    61,
      -1,    63,    -1,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    44,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    -1,    -1,    -1,    57,    -1,    -1,    -1,
      61,    -1,    -1,    -1,    -1,    66,    23,    24,    25,    26,
      27,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,    -1,
      -1,    48,    49,    50,    51,    52,    53,    -1,    -1,    -1,
      57,    -1,    -1,    -1,    61,    -1,    -1,    -1,    -1,    66,
      23,    24,    25,    26,    27,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    44,    -1,    -1,    -1,    48,    49,    50,    51,    52,
      53,    23,    24,    25,    26,    27,    -1,    -1,    61,    -1,
      -1,    64,    -1,    66,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    44,    -1,    -1,    -1,    48,    49,    50,    51,
      52,    53,    23,    24,    25,    26,    27,    -1,    -1,    61,
      -1,    -1,    64,    -1,    66,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    44,    -1,    -1,    -1,    48,    49,    50,
      51,    52,    53,    23,    24,    25,    26,    27,    -1,    -1,
      61,    -1,    -1,    64,    -1,    66,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    44,    -1,    -1,    -1,    48,    49,
      50,    51,    52,    53,    -1,    -1,    -1,    57,    -1,    -1,
      -1,    61,    -1,    -1,    -1,    -1,    66,    23,    24,    25,
      26,    27,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,    -1,
      -1,    -1,    48,    49,    50,    51,    52,    53,    23,    24,
      25,    26,    27,    -1,    -1,    61,    -1,    -1,    -1,    -1,
      66,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    44,
      -1,    -1,    -1,    48,    49,    50,    51,    52,    53,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    66
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    10,    11,    12,    13,    14,    15,    16,    17,    18,
      29,    30,    31,    37,    38,    39,    47,    51,    58,    69,
      70,    71,    72,    74,    75,    77,    78,    80,    81,    82,
      83,    84,    94,   116,    51,   117,   121,   117,    47,   117,
     117,    10,    11,    13,    10,    11,    12,    13,   117,   117,
     117,    12,    47,    72,    75,    94,   116,    33,    34,    47,
      56,    85,    47,    70,     0,    70,    47,    70,    47,    70,
      47,    70,    70,    70,    70,    58,    59,    62,    58,    47,
      51,    66,   119,   117,    85,   117,   117,   117,   117,   117,
     117,   117,    47,    47,    58,    47,    19,    20,    21,    22,
      27,    33,    45,    46,    47,    48,    49,    51,    56,    59,
      65,   109,   112,   114,   120,    12,    15,    57,    86,   116,
      85,    59,   117,    59,   117,    59,    87,   121,    47,    83,
     116,    47,    61,    62,    66,    85,    95,   118,   119,   121,
      47,    51,    67,    47,    56,   114,    56,    28,    44,    56,
      66,   118,    47,    56,   114,    47,    56,    47,   114,   116,
     115,   120,   114,    23,    24,    25,    26,    27,    44,    48,
      49,    50,    51,    52,    53,    61,   118,    10,    11,    12,
      13,   116,    57,    47,    62,   119,    72,    73,   116,   121,
      47,    75,    76,   116,   121,    47,    47,    62,    79,   121,
       3,     6,     7,     8,     9,    27,    35,    36,    40,    47,
      60,    88,    89,    90,    93,    94,    97,    98,   100,   101,
     102,   103,   104,   105,   109,   110,   112,   114,    47,   118,
      59,   114,    47,    51,   114,    61,    95,    61,    85,    47,
     119,    85,   114,   116,   114,    47,   113,   114,   121,    28,
      61,    44,   118,    51,   114,    57,    57,    57,    60,    62,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   117,   117,    47,    51,   117,   117,    47,    62,
     119,    86,    47,    47,    60,    47,    61,    95,    47,    60,
      47,    61,    95,    61,    79,    47,    60,    56,   111,   114,
     121,   114,    56,    58,     5,    59,    56,    56,    27,    61,
      96,   120,   121,    95,    61,    95,   118,    47,    51,    67,
      59,   114,    85,    57,    57,    28,    61,   118,    57,    62,
     114,   114,    47,    47,    57,   114,   114,   115,    63,    63,
      62,    47,    62,    86,    62,    62,   117,    58,    58,   118,
      59,   114,   117,    58,    58,   118,    59,   114,   120,    61,
      79,    58,   114,   114,    59,    87,    87,   107,   114,   121,
      94,   106,   112,   114,   121,   114,    60,    62,    96,   120,
      59,   114,    61,    95,    61,    95,    47,    51,   118,    96,
      95,   114,   114,    28,    61,   113,   118,    57,    63,   114,
     114,    86,    62,    86,    86,    86,    47,    73,    58,   120,
      95,    47,    76,    58,    96,    95,    79,   120,    57,    57,
      87,    60,    57,    58,    95,    95,    96,    62,    96,    95,
      59,    59,   114,    61,    95,    47,    60,   114,   114,   118,
     114,    64,    64,    86,    58,    73,    60,    58,    76,    60,
      79,    58,    59,    87,    59,    60,   103,    58,    59,    87,
     107,    60,    96,    96,    95,   114,    95,    95,    64,   114,
     114,    73,    95,    76,    95,    87,     4,    99,   121,    41,
      42,    91,   121,    56,    87,    58,    95,    60,    60,    95,
     114,    60,    56,   120,    64,    60,   107,    60,   108,   114,
     121,    95,    95,    99,   114,    64,    88,    92,   121,    57,
      58,    57,    57,    92,    92,    91,    58,    59,    87,    59,
      87,    91,    87,    87,    99,    60,    60,    99
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    68,    69,    70,    70,    70,    70,    70,    70,    70,
      70,    70,    71,    72,    73,    73,    73,    73,    74,    75,
      76,    76,    76,    76,    77,    78,    79,    79,    79,    79,
      79,    80,    80,    81,    81,    82,    82,    82,    83,    83,
      83,    84,    84,    84,    84,    84,    84,    84,    85,    85,
      86,    86,    86,    86,    86,    86,    86,    86,    86,    86,
      86,    86,    86,    86,    86,    87,    87,    88,    88,    88,
      88,    88,    88,    89,    90,    91,    91,    91,    92,    92,
      93,    93,    93,    93,    93,    93,    93,    93,    94,    94,
      94,    94,    94,    94,    94,    94,    94,    94,    94,    94,
      94,    95,    95,    95,    95,    95,    95,    95,    95,    95,
      95,    95,    95,    95,    96,    96,    96,    97,    97,    97,
      98,    98,    98,    99,    99,    99,   100,   101,   102,   102,
     102,   102,   103,   104,   104,   105,   106,   106,   106,   107,
     107,   108,   108,   109,   110,   111,   111,   112,   112,   112,
     112,   112,   112,   112,   112,   112,   112,   112,   113,   113,
     113,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
     114,   114,   114,   114,   114,   114,   114,   115,   115,   116,
     116,   116,   116,   116,   116,   116,   116,   116,   116,   116,
     116,   116,   116,   117,   117,   118,   118,   119,   119,   120,
     120,   120,   120,   121
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     1,     1,     2,     2,     2,     2,     2,     2,
       2,     2,     6,     1,     4,     5,     6,     1,     6,     1,
       4,     5,     6,     1,     6,     1,     4,     2,     5,     3,
       1,     3,     2,     2,     2,     3,    10,     2,     4,     2,
       3,     3,     4,     5,     3,     4,     2,     3,     2,     3,
       2,     3,     3,     4,     1,     3,     4,     5,     5,     6,
       5,     3,     5,     1,     3,     2,     1,     2,     1,     1,
       1,     1,     1,     7,     1,     5,     4,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     3,     4,
       5,     1,     6,     7,     8,     5,     9,     7,     5,     9,
       7,     3,     4,     5,     6,     5,     6,     7,     7,     8,
       4,     8,     5,     1,     3,     2,     1,     1,     5,     3,
       8,     6,     5,     8,     6,     1,     9,     1,     7,     8,
       5,     5,     1,    11,     9,     1,     1,     1,     1,     1,
       1,     1,     1,     4,     2,     1,     1,     3,     7,     7,
       4,     3,     3,     4,     5,     6,     5,     6,     1,     3,
       1,     1,     2,     1,     3,     1,     4,     4,     4,     4,
       1,     1,     1,     2,     2,     2,     6,     3,     3,     4,
       4,     5,     3,     3,     3,     3,     2,     2,     3,     3,
       3,     3,     3,     3,     3,     2,     2,     1,     3,     2,
       3,     2,     3,     2,     3,     2,     3,     3,     3,     3,
       2,     2,     2,     2,     1,     4,     3,     3,     2,     1,
       1,     1,     1,     0
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF

/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)                                \
    do                                                                  \
      if (N)                                                            \
        {                                                               \
          (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;        \
          (Current).first_column = YYRHSLOC (Rhs, 1).first_column;      \
          (Current).last_line    = YYRHSLOC (Rhs, N).last_line;         \
          (Current).last_column  = YYRHSLOC (Rhs, N).last_column;       \
        }                                                               \
      else                                                              \
        {                                                               \
          (Current).first_line   = (Current).last_line   =              \
            YYRHSLOC (Rhs, 0).last_line;                                \
          (Current).first_column = (Current).last_column =              \
            YYRHSLOC (Rhs, 0).last_column;                              \
        }                                                               \
    while (0)
#endif

#define YYRHSLOC(Rhs, K) ((Rhs)[K])


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)


/* YYLOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

# ifndef YYLOCATION_PRINT

#  if defined YY_LOCATION_PRINT

   /* Temporary convenience wrapper in case some people defined the
      undocumented and private YY_LOCATION_PRINT macros.  */
#   define YYLOCATION_PRINT(File, Loc)  YY_LOCATION_PRINT(File, *(Loc))

#  elif defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL

/* Print *YYLOCP on YYO.  Private, do not rely on its existence. */

YY_ATTRIBUTE_UNUSED
static int
yy_location_print_ (FILE *yyo, YYLTYPE const * const yylocp)
{
  int res = 0;
  int end_col = 0 != yylocp->last_column ? yylocp->last_column - 1 : 0;
  if (0 <= yylocp->first_line)
    {
      res += YYFPRINTF (yyo, "%d", yylocp->first_line);
      if (0 <= yylocp->first_column)
        res += YYFPRINTF (yyo, ".%d", yylocp->first_column);
    }
  if (0 <= yylocp->last_line)
    {
      if (yylocp->first_line < yylocp->last_line)
        {
          res += YYFPRINTF (yyo, "-%d", yylocp->last_line);
          if (0 <= end_col)
            res += YYFPRINTF (yyo, ".%d", end_col);
        }
      else if (0 <= end_col && yylocp->first_column < end_col)
        res += YYFPRINTF (yyo, "-%d", end_col);
    }
  return res;
}

#   define YYLOCATION_PRINT  yy_location_print_

    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT(File, Loc)  YYLOCATION_PRINT(File, &(Loc))

#  else

#   define YYLOCATION_PRINT(File, Loc) ((void) 0)
    /* Temporary convenience wrapper in case some people defined the
       undocumented and private YY_LOCATION_PRINT macros.  */
#   define YY_LOCATION_PRINT  YYLOCATION_PRINT

#  endif
# endif /* !defined YYLOCATION_PRINT */


# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value, Location); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  YY_USE (yylocationp);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  YYLOCATION_PRINT (yyo, yylocationp);
  YYFPRINTF (yyo, ": ");
  yy_symbol_value_print (yyo, yykind, yyvaluep, yylocationp);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp, YYLTYPE *yylsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)],
                       &(yylsp[(yyi + 1) - (yynrhs)]));
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, yylsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
{
  YY_USE (yyvaluep);
  YY_USE (yylocationp);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Location data for the lookahead symbol.  */
YYLTYPE yylloc
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  = { 1, 1, 1, 1 }
# endif
;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

    /* The location stack: array, bottom, top.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls = yylsa;
    YYLTYPE *yylsp = yyls;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

  /* The locations where the error started and ended.  */
  YYLTYPE yyerror_range[3];



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  yylsp[0] = yylloc;
  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;
        YYLTYPE *yyls1 = yyls;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yyls1, yysize * YYSIZEOF (*yylsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
        yyls = yyls1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
        YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      yyerror_range[1] = yylloc;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END
  *++yylsp = yylloc;

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location. */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  yyerror_range[1] = yyloc;
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* program: input  */
#line 86 "src/x-grammar.y"
        { printNonTerminal("OK"); }
#line 2074 "gen/x-grammar.c"
    break;

  case 3: /* input: func_def  */
#line 91 "src/x-grammar.y"
                                                        { printNonTerminal("func_def"); }
#line 2080 "gen/x-grammar.c"
    break;

  case 4: /* input: func_def input  */
#line 92 "src/x-grammar.y"
                                                        { printNonTerminal("func_def input"); }
#line 2086 "gen/x-grammar.c"
    break;

  case 5: /* input: global_var_decl input  */
#line 93 "src/x-grammar.y"
                                                        { printNonTerminal("global_var_decl input"); }
#line 2092 "gen/x-grammar.c"
    break;

  case 6: /* input: include input  */
#line 94 "src/x-grammar.y"
                                                                { printNonTerminal("include input"); }
#line 2098 "gen/x-grammar.c"
    break;

  case 7: /* input: define input  */
#line 95 "src/x-grammar.y"
                                                                { printNonTerminal("define input"); }
#line 2104 "gen/x-grammar.c"
    break;

  case 8: /* input: enumeration input  */
#line 96 "src/x-grammar.y"
                                                                { printNonTerminal("enumeration input"); }
#line 2110 "gen/x-grammar.c"
    break;

  case 9: /* input: union input  */
#line 97 "src/x-grammar.y"
                                                                { printNonTerminal("union input"); }
#line 2116 "gen/x-grammar.c"
    break;

  case 10: /* input: struct input  */
#line 98 "src/x-grammar.y"
                                                                { printNonTerminal("struct input"); }
#line 2122 "gen/x-grammar.c"
    break;

  case 12: /* union: union_tok TOK_IDENT '{' union_args '}' ';'  */
#line 106 "src/x-grammar.y"
                                                {  flag_union = 0; printNonTerminal("TOK_UNION TOK_IDENT '{' union_args '}' ';'"); }
#line 2128 "gen/x-grammar.c"
    break;

  case 13: /* union_tok: TOK_UNION  */
#line 110 "src/x-grammar.y"
                                { flag_union = 1; printNonTerminal("TOK_UNION"); }
#line 2134 "gen/x-grammar.c"
    break;

  case 14: /* union_args: type_token TOK_IDENT ';' union_args  */
#line 114 "src/x-grammar.y"
                                                                                                        { printNonTerminal("type_token TOK_IDENT ';' union_args"); }
#line 2140 "gen/x-grammar.c"
    break;

  case 15: /* union_args: type_token TOK_IDENT arr_index_token ';' union_args  */
#line 115 "src/x-grammar.y"
                                                                                        { printNonTerminal("type_token TOK_IDENT arr_index_token ';' union_args"); }
#line 2146 "gen/x-grammar.c"
    break;

  case 16: /* union_args: union_tok TOK_IDENT ident_ref_modifier TOK_IDENT ';' union_args  */
#line 116 "src/x-grammar.y"
                                                                                { printNonTerminal("union_tok TOK_IDENT ident_ref_modifier TOK_IDENT ';' union_args"); }
#line 2152 "gen/x-grammar.c"
    break;

  case 17: /* union_args: empty_rule  */
#line 117 "src/x-grammar.y"
                                                                                                                                        { /* Ничего не пишем */ }
#line 2158 "gen/x-grammar.c"
    break;

  case 18: /* struct: struct_tok TOK_IDENT '{' struct_args '}' ';'  */
#line 122 "src/x-grammar.y"
                                                { flag_struct = 0; printNonTerminal("struct_tok TOK_IDENT '{' struct_args '}' ';'"); }
#line 2164 "gen/x-grammar.c"
    break;

  case 19: /* struct_tok: TOK_STRUCT  */
#line 126 "src/x-grammar.y"
                        { flag_struct = 1; printTerminal("TOK_STRUCT"); }
#line 2170 "gen/x-grammar.c"
    break;

  case 20: /* struct_args: type_token TOK_IDENT ';' struct_args  */
#line 130 "src/x-grammar.y"
                                                                                                        { printNonTerminal("type_token TOK_IDENT ';' struct_args"); }
#line 2176 "gen/x-grammar.c"
    break;

  case 21: /* struct_args: type_token TOK_IDENT arr_index_token ';' struct_args  */
#line 131 "src/x-grammar.y"
                                                                                        { printNonTerminal("type_token arr_index_token TOK_IDENT ';' struct_args"); }
#line 2182 "gen/x-grammar.c"
    break;

  case 22: /* struct_args: struct_tok TOK_IDENT ident_ref_modifier TOK_IDENT ';' struct_args  */
#line 132 "src/x-grammar.y"
                                                                                { printNonTerminal("sruct_tok TOK_IDENT ident_ref_modifier TOK_IDENT ';' struct_args"); }
#line 2188 "gen/x-grammar.c"
    break;

  case 23: /* struct_args: empty_rule  */
#line 133 "src/x-grammar.y"
                                                                                                                                        { /* Ничего не пишем */ }
#line 2194 "gen/x-grammar.c"
    break;

  case 24: /* enumeration: enum_tok TOK_IDENT '{' enum_args '}' ';'  */
#line 138 "src/x-grammar.y"
                                                        { flag_enum = 0; printNonTerminal("enum_tok TOK_IDENT '{' enum_args '}' ';'"); }
#line 2200 "gen/x-grammar.c"
    break;

  case 25: /* enum_tok: TOK_ENUM  */
#line 142 "src/x-grammar.y"
                                { flag_enum = 1; printTerminal("TOK_ENUM"); }
#line 2206 "gen/x-grammar.c"
    break;

  case 26: /* enum_args: TOK_IDENT '=' const_token enum_args  */
#line 146 "src/x-grammar.y"
                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("TOK_IDENT '=' const_token enum_args"); }
#line 2212 "gen/x-grammar.c"
    break;

  case 27: /* enum_args: TOK_IDENT enum_args  */
#line 147 "src/x-grammar.y"
                                                                        { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("TOK_IDENT enum_args"); }
#line 2218 "gen/x-grammar.c"
    break;

  case 28: /* enum_args: ',' TOK_IDENT '=' const_token enum_args  */
#line 148 "src/x-grammar.y"
                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("',' TOK_IDENT '=' const_token enum_args"); }
#line 2224 "gen/x-grammar.c"
    break;

  case 29: /* enum_args: ',' TOK_IDENT enum_args  */
#line 149 "src/x-grammar.y"
                                                                        { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("',' TOK_IDENT enum_args"); }
#line 2230 "gen/x-grammar.c"
    break;

  case 30: /* enum_args: empty_rule  */
#line 150 "src/x-grammar.y"
                                                                                        { /* Ничего не пишем */ }
#line 2236 "gen/x-grammar.c"
    break;

  case 31: /* global_var_decl: TOK_EXTERN decl_statement ';'  */
#line 155 "src/x-grammar.y"
                                                { printNonTerminal("TOK_EXTERN decl_statement ';'"); }
#line 2242 "gen/x-grammar.c"
    break;

  case 32: /* global_var_decl: decl_statement ';'  */
#line 156 "src/x-grammar.y"
                                                        { printNonTerminal("decl_statement ';'"); }
#line 2248 "gen/x-grammar.c"
    break;

  case 33: /* include: TOK_INCLUDE TOK_STRING_INCLUDE  */
#line 161 "src/x-grammar.y"
                                        { printNonTerminal("TOK_INCLUDE TOK_STRING_INCLUDE"); }
#line 2254 "gen/x-grammar.c"
    break;

  case 34: /* include: TOK_INCLUDE TOK_STRING  */
#line 162 "src/x-grammar.y"
                                                { printNonTerminal("TOK_INCLUDE TOK_STRING"); }
#line 2260 "gen/x-grammar.c"
    break;

  case 35: /* define: TOK_DEFINE TOK_IDENT expr  */
#line 167 "src/x-grammar.y"
                                { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("TOK_DEFINE IDENTIFIER expr"); }
#line 2266 "gen/x-grammar.c"
    break;

  case 36: /* define: TOK_DEFINE TOK_IDENT '(' TOK_IDENT ')' expr '?' expr ':' expr  */
#line 168 "src/x-grammar.y"
                                                                        { checkNewDeclaration((yyvsp[-8].name)); printNonTerminal("TOK_DEFINE IDENTIFIER expr"); }
#line 2272 "gen/x-grammar.c"
    break;

  case 38: /* func_def: func_sign '{' func_body '}'  */
#line 172 "src/x-grammar.y"
                                { printNonTerminal("func_sign '{' func_body '}'"); flag_local_var = 0; free_local_vars();}
#line 2278 "gen/x-grammar.c"
    break;

  case 39: /* func_def: func_sign ';'  */
#line 173 "src/x-grammar.y"
                                { printNonTerminal("func_sign ';'"); flag_local_var = 0; }
#line 2284 "gen/x-grammar.c"
    break;

  case 41: /* func_sign: type_token TOK_IDENT sign_arg_cons  */
#line 179 "src/x-grammar.y"
                                                      { flag_local_var = 1; printNonTerminal("type_token TOK_IDENT sign_arg_cons"); }
#line 2290 "gen/x-grammar.c"
    break;

  case 42: /* func_sign: type_token '*' TOK_IDENT sign_arg_cons  */
#line 181 "src/x-grammar.y"
                                                           { flag_local_var = 1; printNonTerminal("type_token TOK_IDENT sign_arg_cons"); }
#line 2296 "gen/x-grammar.c"
    break;

  case 43: /* func_sign: type_token '*' '*' TOK_IDENT sign_arg_cons  */
#line 182 "src/x-grammar.y"
                                                                { flag_local_var = 1; printNonTerminal("type_token TOK_IDENT sign_arg_cons"); }
#line 2302 "gen/x-grammar.c"
    break;

  case 44: /* func_sign: TOK_TYPE_VOID TOK_IDENT sign_arg_cons  */
#line 183 "src/x-grammar.y"
                                                      { flag_local_var = 1; printNonTerminal("TOK_TYPE_VOID TOK_IDENT sign_arg_cons"); }
#line 2308 "gen/x-grammar.c"
    break;

  case 45: /* func_sign: type_token arr_decl_token TOK_IDENT sign_arg_cons  */
#line 184 "src/x-grammar.y"
                                                      { flag_local_var = 1; printNonTerminal("type_token arr_decl_token TOK_IDENT sign_arg_cons"); }
#line 2314 "gen/x-grammar.c"
    break;

  case 48: /* sign_arg_cons: '(' ')'  */
#line 191 "src/x-grammar.y"
                                        { printNonTerminal("'(' ')'"); }
#line 2320 "gen/x-grammar.c"
    break;

  case 49: /* sign_arg_cons: '(' sign_arg_list ')'  */
#line 192 "src/x-grammar.y"
                                        { printNonTerminal("'(' sign_arg_list ')'"); }
#line 2326 "gen/x-grammar.c"
    break;

  case 50: /* sign_arg_list: type_token TOK_IDENT  */
#line 197 "src/x-grammar.y"
                                                                                        { flag_local_var = 1; checkNewDeclaration((yyvsp[0].name));  printNonTerminal("type_token TOK_IDENT"); }
#line 2332 "gen/x-grammar.c"
    break;

  case 51: /* sign_arg_list: TOK_TYPE_CONST type_token TOK_IDENT  */
#line 199 "src/x-grammar.y"
                                                                        { flag_local_var = 1; checkNewDeclaration((yyvsp[0].name));  printNonTerminal("type_token TOK_IDENT"); }
#line 2338 "gen/x-grammar.c"
    break;

  case 52: /* sign_arg_list: TOK_TYPE_CONST TOK_TYPE_VOID TOK_IDENT  */
#line 201 "src/x-grammar.y"
                                                                                { flag_local_var = 1; checkNewDeclaration((yyvsp[0].name));  printNonTerminal("type_token TOK_IDENT"); }
#line 2344 "gen/x-grammar.c"
    break;

  case 53: /* sign_arg_list: TOK_TYPE_CONST TOK_TYPE_VOID '*' TOK_IDENT  */
#line 203 "src/x-grammar.y"
                                                                                { flag_local_var = 1; checkNewDeclaration((yyvsp[0].name));  printNonTerminal("type_token TOK_IDENT"); }
#line 2350 "gen/x-grammar.c"
    break;

  case 55: /* sign_arg_list: type_token arr_decl_token TOK_IDENT  */
#line 207 "src/x-grammar.y"
                                                                                        { flag_local_var = 1; checkNewDeclaration((yyvsp[0].name));  printNonTerminal("type_token arr_decl_token TOK_IDENT"); }
#line 2356 "gen/x-grammar.c"
    break;

  case 56: /* sign_arg_list: type_token TOK_IDENT ',' sign_arg_list  */
#line 209 "src/x-grammar.y"
                                                                                        { flag_local_var = 1; checkNewDeclaration((yyvsp[-2].name));  printNonTerminal("type_token TOK_IDENT ',' sign_arg_list"); }
#line 2362 "gen/x-grammar.c"
    break;

  case 57: /* sign_arg_list: TOK_TYPE_CONST type_token TOK_IDENT ',' sign_arg_list  */
#line 211 "src/x-grammar.y"
                                                                        { flag_local_var = 1; checkNewDeclaration((yyvsp[-2].name));  printNonTerminal("type_token TOK_IDENT ',' sign_arg_list"); }
#line 2368 "gen/x-grammar.c"
    break;

  case 58: /* sign_arg_list: TOK_TYPE_CONST TOK_TYPE_VOID TOK_IDENT ',' sign_arg_list  */
#line 213 "src/x-grammar.y"
                                                                       { flag_local_var = 1; checkNewDeclaration((yyvsp[-2].name));  printNonTerminal("type_token TOK_IDENT ',' sign_arg_list"); }
#line 2374 "gen/x-grammar.c"
    break;

  case 59: /* sign_arg_list: TOK_TYPE_CONST TOK_TYPE_VOID '*' TOK_IDENT ',' sign_arg_list  */
#line 215 "src/x-grammar.y"
                                                                           { flag_local_var = 1; checkNewDeclaration((yyvsp[-2].name));  printNonTerminal("type_token TOK_IDENT ',' sign_arg_list"); }
#line 2380 "gen/x-grammar.c"
    break;

  case 60: /* sign_arg_list: type_token arr_decl_token TOK_IDENT ',' sign_arg_list  */
#line 217 "src/x-grammar.y"
                                                                { flag_local_var = 1; checkNewDeclaration((yyvsp[-2].name));  printNonTerminal("type_token arr_decl_token TOK_IDENT ',' sign_arg_list"); }
#line 2386 "gen/x-grammar.c"
    break;

  case 65: /* func_body: func_body statement  */
#line 227 "src/x-grammar.y"
                        { printNonTerminal("func_body statement"); }
#line 2392 "gen/x-grammar.c"
    break;

  case 66: /* func_body: empty_rule  */
#line 228 "src/x-grammar.y"
                            { /* Ничего не пишем */ }
#line 2398 "gen/x-grammar.c"
    break;

  case 67: /* statement: single_statement ';'  */
#line 233 "src/x-grammar.y"
                        { printNonTerminal("single_statement ';'"); }
#line 2404 "gen/x-grammar.c"
    break;

  case 68: /* statement: if_statement  */
#line 234 "src/x-grammar.y"
                        { printNonTerminal("if_statement"); }
#line 2410 "gen/x-grammar.c"
    break;

  case 69: /* statement: for_statement  */
#line 235 "src/x-grammar.y"
                        { printNonTerminal("for_statement"); }
#line 2416 "gen/x-grammar.c"
    break;

  case 70: /* statement: while_statement  */
#line 236 "src/x-grammar.y"
                                { printNonTerminal("while_statement"); }
#line 2422 "gen/x-grammar.c"
    break;

  case 71: /* statement: do_while_statement  */
#line 237 "src/x-grammar.y"
                        { printNonTerminal("do_while_statement"); }
#line 2428 "gen/x-grammar.c"
    break;

  case 72: /* statement: switch_case  */
#line 238 "src/x-grammar.y"
                                { printNonTerminal("switch_case"); }
#line 2434 "gen/x-grammar.c"
    break;

  case 73: /* switch_case: switch_token '(' expr ')' '{' switch_body '}'  */
#line 243 "src/x-grammar.y"
                                                        { flag_loop = 0; flag_default = 0; printNonTerminal("switch_token '(' expr ')' '{' switch_body '}'"); }
#line 2440 "gen/x-grammar.c"
    break;

  case 74: /* switch_token: TOK_SWITCH  */
#line 247 "src/x-grammar.y"
                        { flag_loop = 1; printTerminal("TOK_SWITCH"); }
#line 2446 "gen/x-grammar.c"
    break;

  case 75: /* switch_body: TOK_CASE const_token ':' case_body switch_body  */
#line 251 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_CASE const_token ':' case_body switch_body"); }
#line 2452 "gen/x-grammar.c"
    break;

  case 76: /* switch_body: TOK_DEFAULT ':' case_body switch_body  */
#line 252 "src/x-grammar.y"
                                                                        { if (flag_default) printNonTerminal("default label is duplicated"); flag_default = 1; printNonTerminal("TOK_DEFAULT ':' case_body switch_body"); }
#line 2458 "gen/x-grammar.c"
    break;

  case 77: /* switch_body: empty_rule  */
#line 253 "src/x-grammar.y"
                                                                                                { /* Ничего не пишем */ }
#line 2464 "gen/x-grammar.c"
    break;

  case 78: /* case_body: statement case_body  */
#line 257 "src/x-grammar.y"
                                { printNonTerminal("statement  case_body"); }
#line 2470 "gen/x-grammar.c"
    break;

  case 79: /* case_body: empty_rule  */
#line 258 "src/x-grammar.y"
                                { /* Ничего не пишем */ }
#line 2476 "gen/x-grammar.c"
    break;

  case 80: /* single_statement: decl_statement  */
#line 263 "src/x-grammar.y"
                                        { printNonTerminal("decl_statement"); }
#line 2482 "gen/x-grammar.c"
    break;

  case 81: /* single_statement: call_expr  */
#line 264 "src/x-grammar.y"
                                        { printNonTerminal("call_expr"); }
#line 2488 "gen/x-grammar.c"
    break;

  case 82: /* single_statement: assign_expr  */
#line 265 "src/x-grammar.y"
                                        { printNonTerminal("assign_expr"); }
#line 2494 "gen/x-grammar.c"
    break;

  case 83: /* single_statement: return_expr  */
#line 266 "src/x-grammar.y"
                                        { printNonTerminal("return_expr"); }
#line 2500 "gen/x-grammar.c"
    break;

  case 84: /* single_statement: TOK_BREAK  */
#line 267 "src/x-grammar.y"
                                        { if (!flag_loop) printTerminal("break is not in loop"); printTerminal("TOK_BREAK"); }
#line 2506 "gen/x-grammar.c"
    break;

  case 85: /* single_statement: TOK_CONTINUE  */
#line 268 "src/x-grammar.y"
                                        { printTerminal("TOK_CONTINUE"); }
#line 2512 "gen/x-grammar.c"
    break;

  case 86: /* single_statement: expr TOK_INC_DEC  */
#line 269 "src/x-grammar.y"
                                                { printNonTerminal("expr TOK_INC_DEC"); }
#line 2518 "gen/x-grammar.c"
    break;

  case 87: /* single_statement: TOK_INC_DEC expr  */
#line 270 "src/x-grammar.y"
                                                { printNonTerminal("TOK_INC_DEC expr"); }
#line 2524 "gen/x-grammar.c"
    break;

  case 88: /* decl_statement: type_token TOK_IDENT decl_list  */
#line 275 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("type_token TOK_IDENT decl_list"); }
#line 2530 "gen/x-grammar.c"
    break;

  case 89: /* decl_statement: type_token TOK_IDENT arr_index_token decl_list  */
#line 277 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-2].name)); printNonTerminal("type_token arr_index_token TOK_IDENT decl_list"); }
#line 2536 "gen/x-grammar.c"
    break;

  case 90: /* decl_statement: type_token TOK_IDENT '=' expr decl_list  */
#line 278 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("type_token TOK_IDENT '=' expr decl_list"); }
#line 2542 "gen/x-grammar.c"
    break;

  case 92: /* decl_statement: type_token TOK_IDENT arr_decl_token '=' expr decl_list  */
#line 281 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-4].name)); printNonTerminal("type_token arr_decl_token TOK_IDENT '=' expr decl_list"); }
#line 2548 "gen/x-grammar.c"
    break;

  case 93: /* decl_statement: type_token TOK_IDENT '=' '{' struct_list_init '}' decl_list  */
#line 283 "src/x-grammar.y"
                                                                                                { checkNewDeclaration((yyvsp[-5].name)); printNonTerminal("type_token TOK_IDENT '=' '{' struct_list_init '}' decl_list"); }
#line 2554 "gen/x-grammar.c"
    break;

  case 94: /* decl_statement: type_token TOK_IDENT arr_index_token '=' '{' struct_list_init '}' decl_list  */
#line 284 "src/x-grammar.y"
                                                                                { checkNewDeclaration((yyvsp[-6].name)); printNonTerminal("type_token TOK_IDENT arr_index_token '=' '{' struct_list_init '}' decl_list"); }
#line 2560 "gen/x-grammar.c"
    break;

  case 95: /* decl_statement: struct_tok TOK_IDENT ident_ref_modifier TOK_IDENT decl_list  */
#line 286 "src/x-grammar.y"
                                                                                                                                { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("struct_tok TOK_IDENT TOK_IDENT decl_list"); flag_struct = 0; }
#line 2566 "gen/x-grammar.c"
    break;

  case 96: /* decl_statement: struct_tok TOK_IDENT ident_ref_modifier TOK_IDENT '=' '{' struct_list_init '}' decl_list  */
#line 287 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-5].name)); printNonTerminal("struct_tok TOK_IDENT TOK_IDENT '=' '{' struct_list_init '}' decl_list"); flag_struct = 0; }
#line 2572 "gen/x-grammar.c"
    break;

  case 97: /* decl_statement: struct_tok TOK_IDENT ident_ref_modifier TOK_IDENT '=' expr decl_list  */
#line 288 "src/x-grammar.y"
                                                                                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("struct_tok TOK_IDENT TOK_IDENT '=' expr decl_list"); flag_struct = 0; }
#line 2578 "gen/x-grammar.c"
    break;

  case 98: /* decl_statement: union_tok TOK_IDENT ident_ref_modifier TOK_IDENT decl_list  */
#line 290 "src/x-grammar.y"
                                                                                                                                { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("union_tok TOK_IDENT TOK_IDENT decl_list"); flag_union = 0; }
#line 2584 "gen/x-grammar.c"
    break;

  case 99: /* decl_statement: union_tok TOK_IDENT ident_ref_modifier TOK_IDENT '=' '{' const_token '}' decl_list  */
#line 291 "src/x-grammar.y"
                                                                                                        { checkNewDeclaration((yyvsp[-5].name)); printNonTerminal("union_tok TOK_IDENT TOK_IDENT '=' '{' const_token '}' decl_list"); flag_union = 0; }
#line 2590 "gen/x-grammar.c"
    break;

  case 100: /* decl_statement: union_tok TOK_IDENT ident_ref_modifier TOK_IDENT '=' expr decl_list  */
#line 292 "src/x-grammar.y"
                                                                                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("union_tok TOK_IDENT TOK_IDENT '=' expr decl_list"); flag_union = 0; }
#line 2596 "gen/x-grammar.c"
    break;

  case 101: /* decl_list: ',' TOK_IDENT decl_list  */
#line 297 "src/x-grammar.y"
                                                                        { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("',' TOK_IDENT decl_list");}
#line 2602 "gen/x-grammar.c"
    break;

  case 102: /* decl_list: ',' '*' TOK_IDENT decl_list  */
#line 298 "src/x-grammar.y"
                                                                                { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("',' TOK_IDENT decl_list");}
#line 2608 "gen/x-grammar.c"
    break;

  case 103: /* decl_list: ',' '*' '*' TOK_IDENT decl_list  */
#line 299 "src/x-grammar.y"
                                                                                { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("',' TOK_IDENT decl_list");}
#line 2614 "gen/x-grammar.c"
    break;

  case 104: /* decl_list: ',' '*' '*' '*' TOK_IDENT decl_list  */
#line 300 "src/x-grammar.y"
                                                                                        { checkNewDeclaration((yyvsp[-1].name)); printNonTerminal("',' TOK_IDENT decl_list");}
#line 2620 "gen/x-grammar.c"
    break;

  case 105: /* decl_list: ',' TOK_IDENT '=' expr decl_list  */
#line 301 "src/x-grammar.y"
                                                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("',' TOK_IDENT '=' expr decl_list"); }
#line 2626 "gen/x-grammar.c"
    break;

  case 106: /* decl_list: ',' '*' TOK_IDENT '=' expr decl_list  */
#line 302 "src/x-grammar.y"
                                                                                        { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("',' TOK_IDENT '=' expr decl_list"); }
#line 2632 "gen/x-grammar.c"
    break;

  case 107: /* decl_list: ',' '*' '*' TOK_IDENT '=' expr decl_list  */
#line 303 "src/x-grammar.y"
                                                                                                { checkNewDeclaration((yyvsp[-3].name)); printNonTerminal("',' TOK_IDENT '=' expr decl_list"); }
#line 2638 "gen/x-grammar.c"
    break;

  case 108: /* decl_list: ',' TOK_IDENT '=' '{' struct_list_init '}' decl_list  */
#line 304 "src/x-grammar.y"
                                                                { checkNewDeclaration((yyvsp[-5].name)); printNonTerminal("',' TOK_IDENT '=' '{' struct_list_init '}' decl_list"); }
#line 2644 "gen/x-grammar.c"
    break;

  case 109: /* decl_list: ',' '*' TOK_IDENT '=' '{' struct_list_init '}' decl_list  */
#line 305 "src/x-grammar.y"
                                                                        { checkNewDeclaration((yyvsp[-5].name)); printNonTerminal("',' TOK_IDENT '=' '{' struct_list_init '}' decl_list"); }
#line 2650 "gen/x-grammar.c"
    break;

  case 113: /* decl_list: empty_rule  */
#line 309 "src/x-grammar.y"
                                                                                                                { /* Ничего не пишем */ }
#line 2656 "gen/x-grammar.c"
    break;

  case 114: /* struct_list_init: const_token ',' struct_list_init  */
#line 314 "src/x-grammar.y"
                                                                                        { printNonTerminal("const_token ',' struct_list_init"); }
#line 2662 "gen/x-grammar.c"
    break;

  case 115: /* struct_list_init: const_token struct_list_init  */
#line 315 "src/x-grammar.y"
                                                                                        { printNonTerminal("const_token  struct_list_init"); }
#line 2668 "gen/x-grammar.c"
    break;

  case 116: /* struct_list_init: empty_rule  */
#line 316 "src/x-grammar.y"
                                                                                                                { /* Ничего не пишем */ }
#line 2674 "gen/x-grammar.c"
    break;

  case 117: /* if_statement: if_statement_head  */
#line 321 "src/x-grammar.y"
                                                { printNonTerminal("if_statement_head"); }
#line 2680 "gen/x-grammar.c"
    break;

  case 118: /* if_statement: if_statement_head TOK_ELSE '{' func_body '}'  */
#line 322 "src/x-grammar.y"
                                                { printNonTerminal("if_statement_head TOK_ELSE '{' func_body '}'"); }
#line 2686 "gen/x-grammar.c"
    break;

  case 119: /* if_statement: if_statement_head TOK_ELSE func_body  */
#line 323 "src/x-grammar.y"
                                        { printNonTerminal("if_statement_head TOK_ELSE func_body "); }
#line 2692 "gen/x-grammar.c"
    break;

  case 120: /* if_statement_head: TOK_IF '(' expr ')' '{' func_body '}' elif_statement  */
#line 328 "src/x-grammar.y"
                                                       { printNonTerminal("TOK_IF '(' expr ')' '{' func_body '}' elif_statement"); }
#line 2698 "gen/x-grammar.c"
    break;

  case 121: /* if_statement_head: TOK_IF '(' expr ')' func_body elif_statement  */
#line 330 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_IF '(' expr ')' func_body elif_statement"); }
#line 2704 "gen/x-grammar.c"
    break;

  case 123: /* elif_statement: TOK_ELIF '(' expr ')' '{' func_body '}' elif_statement  */
#line 336 "src/x-grammar.y"
                                                            { printNonTerminal("TOK_ELIF '(' expr ')' '{' func_body '}' elif_statement"); }
#line 2710 "gen/x-grammar.c"
    break;

  case 124: /* elif_statement: TOK_ELIF '(' expr ')' func_body elif_statement  */
#line 337 "src/x-grammar.y"
                                                     { printNonTerminal("TOK_ELIF '(' expr ')' func_body  elif_statement"); }
#line 2716 "gen/x-grammar.c"
    break;

  case 125: /* elif_statement: empty_rule  */
#line 338 "src/x-grammar.y"
                                                               { /* Ничего не пишем */ }
#line 2722 "gen/x-grammar.c"
    break;

  case 126: /* do_while_statement: do_token '{' func_body '}' while_token '(' loop_expr_2 ')' ';'  */
#line 343 "src/x-grammar.y"
                                                                 { flag_loop = 0; printNonTerminal("do_token '{' func_body '}' while_token '(' loop_expr_2 ')' ';' "); }
#line 2728 "gen/x-grammar.c"
    break;

  case 127: /* do_token: TOK_DO  */
#line 347 "src/x-grammar.y"
                        { flag_loop = 1; printTerminal("TOK_DO"); }
#line 2734 "gen/x-grammar.c"
    break;

  case 128: /* while_statement: while_token '(' loop_expr_2 ')' '{' func_body '}'  */
#line 352 "src/x-grammar.y"
                                                    { flag_loop = 0; printNonTerminal("TOK_WHILE '(' loop_expr_2 ')' '{' func_body '}'"); }
#line 2740 "gen/x-grammar.c"
    break;

  case 129: /* while_statement: while_token '(' loop_expr_2 ')' '{' func_body '}' ';'  */
#line 354 "src/x-grammar.y"
                                                         { flag_loop = 0; printNonTerminal("TOK_WHILE '(' loop_expr_2 ')' '{' func_body '}'"); }
#line 2746 "gen/x-grammar.c"
    break;

  case 130: /* while_statement: while_token '(' loop_expr_2 ')' func_body  */
#line 356 "src/x-grammar.y"
                                              { flag_loop = 0; printNonTerminal("TOK_WHILE '(' loop_expr_2 ')'  func_body "); }
#line 2752 "gen/x-grammar.c"
    break;

  case 131: /* while_statement: while_token '(' loop_expr_2 ')' ';'  */
#line 357 "src/x-grammar.y"
                                      { flag_loop = 0; printNonTerminal("TOK_WHILE '(' loop_expr_2 ')'  func_body "); }
#line 2758 "gen/x-grammar.c"
    break;

  case 132: /* while_token: TOK_WHILE  */
#line 363 "src/x-grammar.y"
                        { flag_loop = 1; printTerminal("TOK_WHILE"); }
#line 2764 "gen/x-grammar.c"
    break;

  case 133: /* for_statement: for_token '(' loop_expr_1 ';' loop_expr_2 ';' loop_expr_3 ')' '{' func_body '}'  */
#line 368 "src/x-grammar.y"
                                                                                  { flag_loop = 0; printNonTerminal("for_token '(' loop_expr_1 ';' loop_expr_2 ';' loop_expr_3 ')' '{' func_body '}'"); }
#line 2770 "gen/x-grammar.c"
    break;

  case 134: /* for_statement: for_token '(' loop_expr_1 ';' loop_expr_2 ';' loop_expr_3 ')' func_body  */
#line 370 "src/x-grammar.y"
                                                                            { flag_loop = 0; printNonTerminal("for_token '(' loop_expr_1 ';' loop_expr_2 ';' loop_expr_3 ')'  func_body "); }
#line 2776 "gen/x-grammar.c"
    break;

  case 135: /* for_token: TOK_FOR  */
#line 374 "src/x-grammar.y"
                        { flag_loop = 1; printTerminal("TOK_FOR"); }
#line 2782 "gen/x-grammar.c"
    break;

  case 136: /* loop_expr_1: decl_statement  */
#line 379 "src/x-grammar.y"
                            { printNonTerminal("decl_statement"); }
#line 2788 "gen/x-grammar.c"
    break;

  case 137: /* loop_expr_1: assign_expr  */
#line 380 "src/x-grammar.y"
                  { printNonTerminal("assign_expr"); }
#line 2794 "gen/x-grammar.c"
    break;

  case 138: /* loop_expr_1: empty_rule  */
#line 381 "src/x-grammar.y"
                             { /* Ничего не пишем */ }
#line 2800 "gen/x-grammar.c"
    break;

  case 139: /* loop_expr_2: expr  */
#line 386 "src/x-grammar.y"
                { printNonTerminal("expr"); }
#line 2806 "gen/x-grammar.c"
    break;

  case 140: /* loop_expr_2: empty_rule  */
#line 387 "src/x-grammar.y"
                        { /* Ничего не пишем */ }
#line 2812 "gen/x-grammar.c"
    break;

  case 141: /* loop_expr_3: expr  */
#line 392 "src/x-grammar.y"
                        { printNonTerminal("expr"); }
#line 2818 "gen/x-grammar.c"
    break;

  case 142: /* loop_expr_3: empty_rule  */
#line 393 "src/x-grammar.y"
                    { /* Ничего не пишем */ }
#line 2824 "gen/x-grammar.c"
    break;

  case 143: /* call_expr: TOK_IDENT '(' arg_cons ')'  */
#line 398 "src/x-grammar.y"
                                { printNonTerminal("TOK_IDENT '(' arg_cons ')'"); }
#line 2830 "gen/x-grammar.c"
    break;

  case 144: /* return_expr: TOK_RET return_expr_tail  */
#line 403 "src/x-grammar.y"
                                        { printNonTerminal("TOK_RET return_expr_tail"); }
#line 2836 "gen/x-grammar.c"
    break;

  case 145: /* return_expr_tail: expr  */
#line 408 "src/x-grammar.y"
                        { printNonTerminal("expr"); }
#line 2842 "gen/x-grammar.c"
    break;

  case 146: /* return_expr_tail: empty_rule  */
#line 409 "src/x-grammar.y"
                                { /* Ничего не пишем */ }
#line 2848 "gen/x-grammar.c"
    break;

  case 147: /* assign_expr: expr '=' expr  */
#line 415 "src/x-grammar.y"
                                        {printNonTerminal("expr '=' expr");}
#line 2854 "gen/x-grammar.c"
    break;

  case 150: /* assign_expr: TOK_IDENT arr_index_token '=' expr  */
#line 419 "src/x-grammar.y"
                                                                { controlDeclaratedVariables((yyvsp[-3].name)); printNonTerminal("TOK_IDENT arr_index_token '=' expr"); }
#line 2860 "gen/x-grammar.c"
    break;

  case 151: /* assign_expr: expr TOK_DOT expr  */
#line 420 "src/x-grammar.y"
                                                                        { printNonTerminal("expr TOK_DOT expr "); }
#line 2866 "gen/x-grammar.c"
    break;

  case 152: /* assign_expr: TOK_IDENT TOK_PRE_ASSIGN_OP expr  */
#line 421 "src/x-grammar.y"
                                                { controlDeclaratedVariables((yyvsp[-2].name)); printNonTerminal("TOK_IDENT TOK_PRE_ASSIGN_OP expr"); }
#line 2872 "gen/x-grammar.c"
    break;

  case 153: /* assign_expr: TOK_IDENT arr_index_token TOK_PRE_ASSIGN_OP expr  */
#line 423 "src/x-grammar.y"
                                                        { controlDeclaratedVariables((yyvsp[-3].name)); printNonTerminal("TOK_IDENT arr_index_token TOK_PRE_ASSIGN_OP expr"); }
#line 2878 "gen/x-grammar.c"
    break;

  case 154: /* assign_expr: TOK_IDENT TOK_DOT TOK_IDENT '=' expr  */
#line 426 "src/x-grammar.y"
                                                                                                        { controlDeclaratedVariables((yyvsp[-4].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT '=' expr"); }
#line 2884 "gen/x-grammar.c"
    break;

  case 155: /* assign_expr: TOK_IDENT TOK_DOT TOK_IDENT arr_index_token '=' expr  */
#line 428 "src/x-grammar.y"
                                                                { controlDeclaratedVariables((yyvsp[-5].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT arr_index_token '=' expr"); }
#line 2890 "gen/x-grammar.c"
    break;

  case 156: /* assign_expr: TOK_IDENT TOK_DOT TOK_IDENT TOK_PRE_ASSIGN_OP expr  */
#line 430 "src/x-grammar.y"
                                                        { controlDeclaratedVariables((yyvsp[-4].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT arr_index_token TOK_PRE_ASSIGN_OP expr"); }
#line 2896 "gen/x-grammar.c"
    break;

  case 157: /* assign_expr: TOK_IDENT TOK_DOT TOK_IDENT arr_index_token TOK_PRE_ASSIGN_OP expr  */
#line 432 "src/x-grammar.y"
                                                                        { controlDeclaratedVariables((yyvsp[-5].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT arr_index_token TOK_PRE_ASSIGN_OP expr"); }
#line 2902 "gen/x-grammar.c"
    break;

  case 158: /* arg_cons: expr  */
#line 439 "src/x-grammar.y"
                            { printNonTerminal("expr"); }
#line 2908 "gen/x-grammar.c"
    break;

  case 159: /* arg_cons: expr ',' arg_cons  */
#line 440 "src/x-grammar.y"
                            { printNonTerminal("expr ',' arg_cons"); }
#line 2914 "gen/x-grammar.c"
    break;

  case 160: /* arg_cons: empty_rule  */
#line 441 "src/x-grammar.y"
                               { /* Ничего не пишем */ }
#line 2920 "gen/x-grammar.c"
    break;

  case 161: /* expr: const_token  */
#line 446 "src/x-grammar.y"
                                                                        { printNonTerminal("const_token"); }
#line 2926 "gen/x-grammar.c"
    break;

  case 162: /* expr: '*' TOK_IDENT  */
#line 448 "src/x-grammar.y"
                                { printNonTerminal(" '*' TOK_IDENT   "); }
#line 2932 "gen/x-grammar.c"
    break;

  case 163: /* expr: assign_expr  */
#line 451 "src/x-grammar.y"
                                                { printNonTerminal("assign_expr"); }
#line 2938 "gen/x-grammar.c"
    break;

  case 166: /* expr: TOK_SIZEOF '(' expr ')'  */
#line 457 "src/x-grammar.y"
                                                                                { printNonTerminal("TOK_SIZEOF '(' expr ')'"); }
#line 2944 "gen/x-grammar.c"
    break;

  case 167: /* expr: '*' '(' expr ')'  */
#line 459 "src/x-grammar.y"
                                                                { printNonTerminal("'*' '(' expr ')'"); }
#line 2950 "gen/x-grammar.c"
    break;

  case 168: /* expr: TOK_SIZEOF '(' type_token ')'  */
#line 461 "src/x-grammar.y"
                                                                        { printNonTerminal("TOK_SIZEOF '(' type_token ')'"); }
#line 2956 "gen/x-grammar.c"
    break;

  case 169: /* expr: '(' type_token ')' expr  */
#line 463 "src/x-grammar.y"
                                                                                { printNonTerminal("'(' type_token ')' expr"); }
#line 2962 "gen/x-grammar.c"
    break;

  case 170: /* expr: call_expr  */
#line 465 "src/x-grammar.y"
                                                                        { printNonTerminal("call_expr"); }
#line 2968 "gen/x-grammar.c"
    break;

  case 171: /* expr: TOK_NULL  */
#line 467 "src/x-grammar.y"
                                                                                                { printTerminal("TOK_NULL"); }
#line 2974 "gen/x-grammar.c"
    break;

  case 172: /* expr: TOK_IDENT  */
#line 469 "src/x-grammar.y"
                                                                        { controlDeclaratedVariables((yyvsp[0].name)); printNonTerminal("TOK_IDENT_expr"); }
#line 2980 "gen/x-grammar.c"
    break;

  case 173: /* expr: '&' TOK_IDENT  */
#line 471 "src/x-grammar.y"
                                                                { controlDeclaratedVariables((yyvsp[0].name)); printNonTerminal("'&' TOK_IDENT"); }
#line 2986 "gen/x-grammar.c"
    break;

  case 175: /* expr: TOK_IDENT arr_index_token  */
#line 475 "src/x-grammar.y"
                                                                        { controlDeclaratedVariables((yyvsp[-1].name)); printNonTerminal("TOK_IDENT arr_index_token"); }
#line 2992 "gen/x-grammar.c"
    break;

  case 177: /* expr: '&' TOK_IDENT arr_index_token  */
#line 479 "src/x-grammar.y"
                                                                { controlDeclaratedVariables((yyvsp[-1].name)); printNonTerminal("'&' TOK_IDENT arr_index_token"); }
#line 2998 "gen/x-grammar.c"
    break;

  case 178: /* expr: TOK_IDENT TOK_DOT TOK_IDENT  */
#line 481 "src/x-grammar.y"
                                                                        { controlDeclaratedVariables((yyvsp[-2].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT"); }
#line 3004 "gen/x-grammar.c"
    break;

  case 179: /* expr: '&' TOK_IDENT TOK_DOT TOK_IDENT  */
#line 483 "src/x-grammar.y"
                                                                        { controlDeclaratedVariables((yyvsp[-2].name)); printNonTerminal("'&' TOK_IDENT TOK_DOT TOK_IDENT"); }
#line 3010 "gen/x-grammar.c"
    break;

  case 180: /* expr: TOK_IDENT TOK_DOT TOK_IDENT arr_index_token  */
#line 485 "src/x-grammar.y"
                                                        { controlDeclaratedVariables((yyvsp[-3].name)); printNonTerminal("TOK_IDENT TOK_DOT TOK_IDENT arr_index_token"); }
#line 3016 "gen/x-grammar.c"
    break;

  case 181: /* expr: '&' TOK_IDENT TOK_DOT TOK_IDENT arr_index_token  */
#line 487 "src/x-grammar.y"
                                                    { controlDeclaratedVariables((yyvsp[-3].name)); printNonTerminal("'&' TOK_IDENT TOK_DOT TOK_IDENT arr_index_token"); }
#line 3022 "gen/x-grammar.c"
    break;

  case 182: /* expr: '(' expr ')'  */
#line 490 "src/x-grammar.y"
                                                                        { printNonTerminal("'(' expr ')'"); }
#line 3028 "gen/x-grammar.c"
    break;

  case 183: /* expr: expr TOK_SHIFT_OP expr  */
#line 492 "src/x-grammar.y"
                                                                                { printNonTerminal("expr TOK_SHIFT_OP expr"); }
#line 3034 "gen/x-grammar.c"
    break;

  case 184: /* expr: expr TOK_BIT_OP expr  */
#line 494 "src/x-grammar.y"
                                                                                { printNonTerminal("expr TOK_BIT_OP expr"); }
#line 3040 "gen/x-grammar.c"
    break;

  case 185: /* expr: expr '&' expr  */
#line 496 "src/x-grammar.y"
                                                                                        { printNonTerminal("expr '&' expr"); }
#line 3046 "gen/x-grammar.c"
    break;

  case 186: /* expr: expr TOK_INC_DEC  */
#line 498 "src/x-grammar.y"
                                                                                        { printNonTerminal("expr TOK_INC_DEC"); }
#line 3052 "gen/x-grammar.c"
    break;

  case 187: /* expr: TOK_INC_DEC expr  */
#line 500 "src/x-grammar.y"
                                                                                        { printNonTerminal("TOK_INC_DEC expr"); }
#line 3058 "gen/x-grammar.c"
    break;

  case 188: /* expr: expr '+' expr  */
#line 502 "src/x-grammar.y"
                                                                        { printNonTerminal("expr '+' expr"); }
#line 3064 "gen/x-grammar.c"
    break;

  case 189: /* expr: expr '-' expr  */
#line 504 "src/x-grammar.y"
                                                                        { printNonTerminal("expr '-' expr"); }
#line 3070 "gen/x-grammar.c"
    break;

  case 190: /* expr: expr '*' expr  */
#line 506 "src/x-grammar.y"
                                                                        { printNonTerminal("expr '*' expr"); }
#line 3076 "gen/x-grammar.c"
    break;

  case 191: /* expr: expr '/' expr  */
#line 508 "src/x-grammar.y"
                                                                        { printNonTerminal("expr '/' expr"); }
#line 3082 "gen/x-grammar.c"
    break;

  case 192: /* expr: expr '%' expr  */
#line 510 "src/x-grammar.y"
                                                                        { printNonTerminal("expr ' ' expr"); }
#line 3088 "gen/x-grammar.c"
    break;

  case 193: /* expr: expr TOK_LOGIC expr  */
#line 512 "src/x-grammar.y"
                                                                        { printNonTerminal("expr TOK_LOGIC expr"); }
#line 3094 "gen/x-grammar.c"
    break;

  case 194: /* expr: expr TOK_COMPARE expr  */
#line 516 "src/x-grammar.y"
                                                                        { printNonTerminal("expr TOK_COMPARE expr"); }
#line 3100 "gen/x-grammar.c"
    break;

  case 195: /* expr: '-' expr  */
#line 518 "src/x-grammar.y"
                                                                        { printNonTerminal("'-' expr  prec TOK_UMIN"); }
#line 3106 "gen/x-grammar.c"
    break;

  case 196: /* expr: '!' expr  */
#line 520 "src/x-grammar.y"
                                                                        { printNonTerminal("'!' expr  prec TOK_NOT"); }
#line 3112 "gen/x-grammar.c"
    break;

  case 199: /* type_token: TOK_TYPE_INT ident_ref_modifier  */
#line 531 "src/x-grammar.y"
                                        { printNonTerminal("TOK_TYPE_INT  ident_ref_modifier"); }
#line 3118 "gen/x-grammar.c"
    break;

  case 200: /* type_token: TOK_TYPE_CONST TOK_TYPE_INT ident_ref_modifier  */
#line 532 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_INT  ident_ref_modifier"); }
#line 3124 "gen/x-grammar.c"
    break;

  case 201: /* type_token: TOK_TYPE_CHAR ident_ref_modifier  */
#line 533 "src/x-grammar.y"
                                        { printNonTerminal("TOK_TYPE_CHAR  ident_ref_modifier"); }
#line 3130 "gen/x-grammar.c"
    break;

  case 202: /* type_token: TOK_TYPE_CONST TOK_TYPE_CHAR ident_ref_modifier  */
#line 534 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_CHAR  ident_ref_modifier"); }
#line 3136 "gen/x-grammar.c"
    break;

  case 203: /* type_token: TOK_TYPE_FLOAT ident_ref_modifier  */
#line 535 "src/x-grammar.y"
                                        { printNonTerminal("TOK_TYPE_FLOAT  ident_ref_modifier"); }
#line 3142 "gen/x-grammar.c"
    break;

  case 204: /* type_token: TOK_TYPE_CONST TOK_TYPE_FLOAT ident_ref_modifier  */
#line 536 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_FLOAT  ident_ref_modifier"); }
#line 3148 "gen/x-grammar.c"
    break;

  case 205: /* type_token: TOK_TYPE_VOID ident_ref_modifier  */
#line 537 "src/x-grammar.y"
                                        { printNonTerminal("TOK_TYPE_FLOAT  ident_ref_modifier"); }
#line 3154 "gen/x-grammar.c"
    break;

  case 206: /* type_token: TOK_TYPE_CONST TOK_TYPE_VOID ident_ref_modifier  */
#line 538 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_FLOAT  ident_ref_modifier"); }
#line 3160 "gen/x-grammar.c"
    break;

  case 207: /* type_token: TOK_TYPE_STATIC TOK_TYPE_INT ident_ref_modifier  */
#line 539 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_INT  ident_ref_modifier"); }
#line 3166 "gen/x-grammar.c"
    break;

  case 208: /* type_token: TOK_TYPE_STATIC TOK_TYPE_CHAR ident_ref_modifier  */
#line 540 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_CHAR  ident_ref_modifier"); }
#line 3172 "gen/x-grammar.c"
    break;

  case 209: /* type_token: TOK_TYPE_STATIC TOK_TYPE_FLOAT ident_ref_modifier  */
#line 541 "src/x-grammar.y"
                                                        { printNonTerminal("TOK_TYPE_FLOAT  ident_ref_modifier"); }
#line 3178 "gen/x-grammar.c"
    break;

  case 210: /* type_token: TOK_TYPE_FILE ident_ref_modifier  */
#line 542 "src/x-grammar.y"
                                   { printNonTerminal("TOK_TYPE_FILE  ident_ref_modifier"); }
#line 3184 "gen/x-grammar.c"
    break;

  case 211: /* type_token: TOK_TYPE__Bool ident_ref_modifier  */
#line 543 "src/x-grammar.y"
                                    { printNonTerminal("TOK_TYPE__Bool  ident_ref_modifier"); }
#line 3190 "gen/x-grammar.c"
    break;

  case 212: /* type_token: TOK_TYPE_size_t ident_ref_modifier  */
#line 544 "src/x-grammar.y"
                                     { printNonTerminal("TOK_TYPE__Bool  ident_ref_modifier"); }
#line 3196 "gen/x-grammar.c"
    break;

  case 213: /* ident_ref_modifier: '*' ident_ref_modifier  */
#line 549 "src/x-grammar.y"
                                {  printNonTerminal(" '*'   ident_ref_modifier"); }
#line 3202 "gen/x-grammar.c"
    break;

  case 214: /* ident_ref_modifier: empty_rule  */
#line 550 "src/x-grammar.y"
                                                { /* Ничего не пишем */ }
#line 3208 "gen/x-grammar.c"
    break;

  case 215: /* arr_index_token: '[' expr ']' arr_index_token  */
#line 555 "src/x-grammar.y"
                                                { printNonTerminal("'[' expr ']'  arr_index_token"); }
#line 3214 "gen/x-grammar.c"
    break;

  case 216: /* arr_index_token: '[' expr ']'  */
#line 556 "src/x-grammar.y"
                                                { printNonTerminal("'[' expr ']'"); }
#line 3220 "gen/x-grammar.c"
    break;

  case 217: /* arr_decl_token: '[' ']' arr_decl_token  */
#line 561 "src/x-grammar.y"
                                                { printNonTerminal("'[' ']' arr_decl_token"); }
#line 3226 "gen/x-grammar.c"
    break;

  case 218: /* arr_decl_token: '[' ']'  */
#line 562 "src/x-grammar.y"
                                                                { printNonTerminal("'[' ']'"); }
#line 3232 "gen/x-grammar.c"
    break;

  case 219: /* const_token: TOK_INT  */
#line 567 "src/x-grammar.y"
                { printTerminal("TOK_INT"); }
#line 3238 "gen/x-grammar.c"
    break;

  case 220: /* const_token: TOK_CHAR  */
#line 568 "src/x-grammar.y"
                { printTerminal("TOK_CHAR"); }
#line 3244 "gen/x-grammar.c"
    break;

  case 221: /* const_token: TOK_FLOAT  */
#line 569 "src/x-grammar.y"
                { printTerminal("TOK_FLOAT"); }
#line 3250 "gen/x-grammar.c"
    break;

  case 222: /* const_token: TOK_STRING  */
#line 570 "src/x-grammar.y"
                { printTerminal("TOK_STRING"); }
#line 3256 "gen/x-grammar.c"
    break;


#line 3260 "gen/x-grammar.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  yyerror_range[1] = yylloc;
  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval, &yylloc);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  yyerror_range[2] = yylloc;
  ++yylsp;
  YYLLOC_DEFAULT (*yylsp, yyerror_range, 2);

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 575 "src/x-grammar.y"


/**
 * Данная функция автоматически вызывается bison'ом если на вход поступает
 * токен, не удовлетворяющий ни одному правилу
 */
void yyerror(char const * msg)
{
    fprintf (stderr,
             "Ошибка: %d:%d: %s\n",
             yylloc.first_line,
             yylloc.first_column,
             msg);
    exit(1);
}

static void printTerminal(const char * tokName)
{
    printf("<%s, \"%s\", %d:%d, %d:%d>\n",
           tokName,
           yytext,
           yylloc.first_line,
           yylloc.first_column,
           yylloc.last_line,
           yylloc.last_column);
}

static void printNonTerminal(const char * tokName)
{
    printf("<%s>\n", tokName);
}

void checkNewDeclaration(const char * identificator)
{
	checkVariables(local_vars, &count_local_vars, identificator); /* Заносим переменную локально (если мы сейчас не в функции, то ниже обнулится */
	
	if (!flag_local_var) /* Т.е. это не в локальной функции - будет глобальная видимость переменных */
	{
		checkVariables(global_vars, &count_global_vars, identificator);
		free_local_vars();
	}
}

void checkVariables(char variables[MAX_COUNT][MAX_NAME], int* count, const char * identificator)
{
	for (int i = 0; i < *count; ++i)
	{
		if (!strcmp(variables[i], identificator))
		{
			printNonTerminal("Duplication of variable");
		}
	}

	strcpy(variables[*count], identificator);
	++(*count);
}

void free_local_vars()
{
	memset(local_vars, 0, sizeof(local_vars));
	count_local_vars = 0;
}
 
void controlDeclaratedVariables(const char * identificator)
{
	for (int i = 0; i < count_local_vars; ++i)
	{
		if (!strcmp(local_vars[i], identificator)) /* Если такая переменная уже была объявлена локально, то все окей */
		{
			return;
		}
	}	
	for (int i = 0; i < count_global_vars; ++i)
	{
		if (!strcmp(global_vars[i], identificator)) /* Если такая переменная уже была объявлена глобально, то все окей */
		{
			return;
		}
	}
	printNonTerminal("Undeclared variable");
	//yyerror("Undeclared variable");
}

void newConstructionNameCheck(const char * identificator)
{
	if (flag_struct) {
		checkVariables(struct_construct, &count_struct, identificator);	/* Смотрим на то, является ли это структурой */
	}		
	else if (flag_union) {
		checkVariables(union_construct, &count_union, identificator);	/* Смотрим на то, является ли это объединением */
	}			
}

void controlConstructionName(const char * identificator)
{
	for (int i = 0; i < count_struct; ++i)
	{
		if (!strcmp(struct_construct[i], identificator)) /* Если такая структура уже объявлена, то все окей */
		{
			return;
		}
	}	
	for (int i = 0; i < count_union; ++i)
	{
		if (!strcmp(union_construct[i], identificator)) /* Если такое объединение уже объявлено, то все окей */
		{
			return;
		}
	}	
	yyerror("Undeclared construction name");
}
