/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

#ifndef YY_YY_GEN_X_GRAMMAR_H_INCLUDED
# define YY_YY_GEN_X_GRAMMAR_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    TOK_IF = 258,                  /* TOK_IF  */
    TOK_ELIF = 259,                /* TOK_ELIF  */
    TOK_ELSE = 260,                /* TOK_ELSE  */
    TOK_FOR = 261,                 /* TOK_FOR  */
    TOK_BREAK = 262,               /* TOK_BREAK  */
    TOK_CONTINUE = 263,            /* TOK_CONTINUE  */
    TOK_RET = 264,                 /* TOK_RET  */
    TOK_TYPE_CHAR = 265,           /* TOK_TYPE_CHAR  */
    TOK_TYPE_FLOAT = 266,          /* TOK_TYPE_FLOAT  */
    TOK_TYPE_VOID = 267,           /* TOK_TYPE_VOID  */
    TOK_TYPE_INT = 268,            /* TOK_TYPE_INT  */
    TOK_TYPE_STATIC = 269,         /* TOK_TYPE_STATIC  */
    TOK_TYPE_CONST = 270,          /* TOK_TYPE_CONST  */
    TOK_TYPE_FILE = 271,           /* TOK_TYPE_FILE  */
    TOK_TYPE__Bool = 272,          /* TOK_TYPE__Bool  */
    TOK_TYPE_size_t = 273,         /* TOK_TYPE_size_t  */
    TOK_CHAR = 274,                /* TOK_CHAR  */
    TOK_INT = 275,                 /* TOK_INT  */
    TOK_FLOAT = 276,               /* TOK_FLOAT  */
    TOK_HEX_NUMBER = 277,          /* TOK_HEX_NUMBER  */
    TOK_LOGIC = 278,               /* TOK_LOGIC  */
    TOK_COMPARE = 279,             /* TOK_COMPARE  */
    TOK_SHIFT_OP = 280,            /* TOK_SHIFT_OP  */
    TOK_BIT_OP = 281,              /* TOK_BIT_OP  */
    TOK_INC_DEC = 282,             /* TOK_INC_DEC  */
    TOK_PRE_ASSIGN_OP = 283,       /* TOK_PRE_ASSIGN_OP  */
    TOK_EXTERN = 284,              /* TOK_EXTERN  */
    TOK_INCLUDE = 285,             /* TOK_INCLUDE  */
    TOK_DEFINE = 286,              /* TOK_DEFINE  */
    TOK_STRING_DEFINE = 287,       /* TOK_STRING_DEFINE  */
    TOK_STRING = 288,              /* TOK_STRING  */
    TOK_STRING_INCLUDE = 289,      /* TOK_STRING_INCLUDE  */
    TOK_WHILE = 290,               /* TOK_WHILE  */
    TOK_DO = 291,                  /* TOK_DO  */
    TOK_ENUM = 292,                /* TOK_ENUM  */
    TOK_UNION = 293,               /* TOK_UNION  */
    TOK_STRUCT = 294,              /* TOK_STRUCT  */
    TOK_SWITCH = 295,              /* TOK_SWITCH  */
    TOK_CASE = 296,                /* TOK_CASE  */
    TOK_DEFAULT = 297,             /* TOK_DEFAULT  */
    TOK_ERROR = 298,               /* TOK_ERROR  */
    TOK_DOT = 299,                 /* TOK_DOT  */
    TOK_NULL = 300,                /* TOK_NULL  */
    TOK_SIZEOF = 301,              /* TOK_SIZEOF  */
    TOK_IDENT = 302,               /* TOK_IDENT  */
    TOK_UMIN = 303,                /* TOK_UMIN  */
    TOK_NOT = 304                  /* TOK_NOT  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 62 "src/x-grammar.y"

 char *name;

#line 117 "gen/x-grammar.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

/* Location type.  */
#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE YYLTYPE;
struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
};
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


extern YYSTYPE yylval;
extern YYLTYPE yylloc;

int yyparse (void);


#endif /* !YY_YY_GEN_X_GRAMMAR_H_INCLUDED  */
