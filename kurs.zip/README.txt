Запуск тестов:
cd bin/release
./compiler ../../tests/1.1.c
