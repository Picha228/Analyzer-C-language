#include <stdio.h>
#include <malloc.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

//нужно два стэка - один для операций, другой - для чисел

struct digit // для чисел
{
    int value;
    struct digit* Next;
};

struct operation // для операций
{
    char value;
    struct operation* Next;
};

struct operation* Stack_Top_operate = NULL;

void push_stack_operate(char data)
{
    struct operation* New = NULL;
    New = malloc(8);
    New->value = data;
    New->Next = Stack_Top_operate;
    Stack_Top_operate = New;
}

char pop_operate()
{
    char final;
    struct operation* Previous = Stack_Top_operate;
    Stack_Top_operate = Stack_Top_operate->Next;
    final = Previous->value;
    free(Previous);

    return final;
}

struct digit* Stack_Top_digit = NULL;

void push_stack_digit(int data)
{
    struct digit* New = NULL;
    New = malloc(8);
    New->value = data;
    New->Next = Stack_Top_digit;
    Stack_Top_digit = New;
}

int pop_digit()
{
    int final;
    struct digit* Previous = Stack_Top_digit;
    Stack_Top_digit = Stack_Top_digit->Next;
    final = Previous->value;
    free(Previous);

    return final;
}

void choise_oper(char c)
{
    int a;
    int b;
    switch (c)
    {
    case '+': push_stack_digit(pop_digit() + pop_digit()); break;
    case '!':push_stack_digit(pop_digit() * -1); break;
    case '-': push_stack_digit(-pop_digit() + pop_digit()); break;
    case '*': push_stack_digit(pop_digit() * pop_digit()); break;
    case '/':
        a = pop_digit();
        b = pop_digit();
        if (a == 0)
        {
           printf("Error");
           exit(1);
        } 
        push_stack_digit(b / a);
        break;
    case '%':
        a = pop_digit();
        b = pop_digit();
        if (a == 0)
        {
            printf("Error");
            exit(1);
        }
        push_stack_digit(b % a);
        break;
    case '^':
        a = pop_digit();
        b = pop_digit();
        push_stack_digit(pow(b, a));
        break;
    }
}

void check(char* mass)
{
    if (mass[0] == '-') {
    	mass[0] = '!';
	}

    int oper = 0, dig = 0;

    for (int i = 1; i < strlen(mass); i++)
    {
        if (mass[i] == '-')
        {
            for (int j = i - 1; j >= 0; j--)
            {
                if (mass[j] > 47 && mass[j] < 58) //если буква
                {
                    dig++;
                    break;
                }
                else if (mass[j] != '(' && mass[j] != ')' && mass[j] != '!') { //если не просто скобки
                	oper++;
                }	
            }
            if (oper != 0 || dig == 0)
            {
                oper = 0;
                mass[i] = '!';
            }
            dig = 0;
        }
    }
}

int oper_check(char* mass)
{
    for (int i = 0; i < strlen(mass); i++)
    {
        if (mass[i] == '!' || mass[i] == '(') {
            continue;
        } 
        else {
            return 1;
        }    
    }
    return 0;
}

int main()
{
    char ch;
    char* sep = "*+-/^%()!";
    char* nums = "0123456789";
    char* tocken;
    char* oper_tocken; 
    char* one; //context
    char* two; 
    char* str = (char*)malloc(sizeof(char) * 2500); // выделяем память для всей строки (максимум 2500)
    gets(str);//вводим строчку

    //strtok работает некорректно, если требуется две подобной функции в программе

    check(str); // Замена унарных минусов на новый символ с наивысшим приоритетом '!';

    char* new_str = malloc(strlen(str));
    strcpy(new_str, str);

    tocken = strtok_s(str, sep, &one); //число
    oper_tocken = strtok_s(new_str, nums, &two); //знак

    char symbol;

    do {
        if (tocken != NULL) {
            push_stack_digit(atoi(tocken));
        }    

        if (oper_tocken != NULL)
        {
            while (!oper_check(oper_tocken))
            {
                int end = 0;

                for (int j = 0; j < strlen(oper_tocken); j++)
                {
                    push_stack_operate(oper_tocken[j]);
                    if (j == strlen(oper_tocken) - 1) {
                        end++;
                    }    
                    if (end != 0) {
                        break;
                    }    
                }
                oper_tocken = strtok_s(NULL, nums, &two);
            }


            for (int i = 0; i < strlen(oper_tocken); i++)
            {
                symbol = oper_tocken[i];

                if (symbol == '(') {
                	push_stack_operate(symbol);
				}
                else if (symbol == ')')
                {
                    while (Stack_Top_operate->value != '(')
                    {
                        ch = pop_operate();
                        choise_oper(ch);
                    }
                    pop_operate();
                }
                else if (symbol == '!') // высший приоритет
                {
                    push_stack_operate(symbol);
                }
                else if (symbol == '^') 
                {
                    if (Stack_Top_operate != '!')
                    {
                        push_stack_operate(symbol);
                    }
                    else
                    {
                        while (Stack_Top_operate->value == '!')
                        {
                            ch = pop_operate();
                            choise_oper(ch);
                        }
                    }
                }

                else if (symbol == '/' || symbol == '%' || symbol == '*')
                {
                    if (Stack_Top_operate == NULL || Stack_Top_operate->value == '+' || Stack_Top_operate->value == '-' || Stack_Top_operate->value == '(') ////////////// скобочка
                    {
                        push_stack_operate(symbol);
                    }
                    else if (Stack_Top_operate->value == '^' || Stack_Top_operate->value == '!' || Stack_Top_operate->value == '%' || Stack_Top_operate->value == '/' || Stack_Top_operate->value == '*')//
                    {
                        while (Stack_Top_operate != NULL)
                        {
                            if (Stack_Top_operate->value != '+' && Stack_Top_operate->value != '-' && Stack_Top_operate->value != '(') //&&
                            {
                                ch = pop_operate();
                                choise_oper(ch);
                            }
                            else {
                                break;
                            }
                        }
                        push_stack_operate(symbol);
                    }
                }
                else if (symbol == '+' || symbol == '-')
                {
                        if (Stack_Top_operate == NULL || Stack_Top_operate->value == '(')
                        {
                            push_stack_operate(symbol);
                        }
                        else
                        {
                            while (Stack_Top_operate != NULL)
                            {
                                if (Stack_Top_operate->value != '(')
                                {
                                    ch = pop_operate();
                                    choise_oper(ch);
                                }
                                else {
                                	break;
                            	}
                            }
                            push_stack_operate(symbol);
                        }
                }

                else
                {
                    int data = atoi(tocken);
                    push_stack_digit(data);
                }

            }
        }

        tocken = strtok_s(NULL, sep, &one);
        oper_tocken = strtok_s(NULL, nums, &two);

    } while (tocken != NULL || oper_tocken != NULL);

    while (Stack_Top_operate != NULL)
    {
        ch = pop_operate();
        choise_oper(ch);
    }

    printf("Data = %d ", Stack_Top_digit->value);
}
