/* Проверка с комментарием, это язык С */
#include <stdio.h>
#include "string.h"

extern int c = 0;
int d = 0;

int ser;

enum help_enum
{ 
	one,
	second = 0,
	third = 0
};

struct true_structure {
	float a[5];
	char b;
};	

union true_union {
	float a[5];
	char b;
};	

void foo()
{
int i = 4;
	int e = 0;
}

int main(int argc, int** argv)
{
	char** e = "HELLO";
	float a = one;
	float s = second;
	float v = 0.0;
	struct true_structure A = { 0, 0};
	A.a = 7.0;
	a += 7;
	
	union true_union B = { 120 };
	
	ser = 5 + 7;
	switch (c > 5)
	{
	case 1:
		s = 9.0;
		break;
	default:
		a = 0;
	}

	int i = 5;
	if (a>>d)
	{
		do 
		{
			i = i + 1;
			break;
		} while(++i);
	}
	return 0;
}
