#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <math.h>
#include <time.h>

unsigned long long a = 6364136223846793005, c = 1442695040888963407; //выбранные параметры
unsigned long long seed = 0; //число относительно которого формируется последовательность
int mass[10000] = { 0 }; // лкг последовательность
int b[1000] = { 0 }; // кол-во разных элементов

//Условия для правильных a и c для получения максимального периода:
//   1) С - любое простое число (т.к. m = 2^64)
//	 2) a mod 8 = 5;
//   3) (a - 1) кратно для каждого p, который является простым делителем m
//   4) (a - 1) кратно 4, если m кратно 4 (а это правда)
//   5) 0 < a < m, 0 <= c < m

// Множителей имеющих простой вид стоит избегать 

int* perevod2(int* final) 
{
	for (int i = 0; i < 1000; i++)
	{
		final[i] = mass[i] % 64;
	}
	return final;
}

unsigned long long lcg()
{
	seed = seed * a + c;
	return seed;
}

void freq()
{
	for (int i = 0; i < 1000; i++)
	{	
		mass[i] = lcg(seed) % 1000; 

		for (int j = 0; j < 1000; j++)  
		{
			if (mass[i] == j)
			{
				b[j]++;
				break;
			}
		}
	}
	
	int max = b[0];
	int min = b[0];
	for (int k = 0; k < 1000; k++)
	{
		if (b[k] > max) { max = b[k]; }
		if (b[k] < min) { min = b[k]; }
	}

	printf("The minimum number of drops of the same number (in the range [0,1000) ) = %d\n", min);
	printf("The maximum number of drops of the same number ( in the range [0,1000) ) = %d\n", max);
	printf("Arithmetic mean (average frequency of occurrence of each of the numbers) = %d\n", (max + min) / 2);
	printf("\n");
}

int X_sqr()
{
	int kolvo_P = sqrt(1000);
	float V = 0; 
	printf("It is necessary to divide the random sequence numbers into groups by %d\n", kolvo_P);
	printf("The groups store the number of elements whose value lies in the intervals from 0 to 99, from 100 to 199, etc.\n");
	printf("It is expected that the probability of elements falling into each group (by equal probability grouping) will be ~ 0.1\n");
	printf("\n");
	
	printf("Number of numbers in each group: \n");
	float group[10] = { 0 };
	for (int i = 0; i < 10; i++)
	{
		for (int j = 100 * i; j < 100 * (i + 1); j++)
		{
			group[i] += b[j]; 
		}
		printf("%d ", group[i]);
		V = V + (group[i] - 0.1 * 1000) * (group[i] - 0.1 * 1000) / (0.1 * 1000); 
		group[i] /= 1000;
	}
	printf("\n");
	printf("The probability of numbers falling into each group:\n");
	for (int k = 0; k < 10; k++)
	{
		printf("%f ", group[i]);
	}
	printf("\n");
	printf("Comparing the obtained value V = %f with the values from the Chi-square table, we found out that it lies between 3.325 and 5.899\n", V);
	printf("Which is a good indicator, because the probability of a hit is from 5 to 25 percent (namely, about 17)\n");
	printf("\n");
}

void conditions()
{
	printf("a = %I64u, c = %I64u \n", a, c);

	if ((a % 8) == 5 && (a - 1) % 4 == 0 ) {
		printf ("The coefficient satisfies the necessary conditions of the theorem \n");
	}
	else {
		printf("The coefficient does NOT satisfy the necessary conditions of the theorem\n");
	}

	if (c % 2 == 1) {
		printf("The coefficient c satisfies the necessary conditions of the theorem\n");
	}
	else {
	printf("The coefficient c does NOT satisfy the necessary conditions of the theorem\n");
	}

	printf("\n");
}

int proverka_bit()
{
	int final[1000] = { 0 };
	int bit[64] = { 0 };

	perevod2(final);

	for (int i = 0; i < 1000; i++)
	{
		for (int j = 0; j < 64; j++)
		{
			if (final[i] == j)
			{
				bit[j] += 1; 
				break;
			}
		}
	}
	
	float group[8] = { 0 };
	printf("Probability of distribution of the lowest bits of the sequence: \n");
}

int correlation()
{
	double sum = 0, sum2 = 0, sumSdvig = 0, before_U = 0;

	for (int i = 0; i < 1000 - 2; i++) 
	{
		double before_S = mass[sum]; 
		double after_S = mass[i + 1]; 

		sum += before_S; 
		sum2 += before_S * before_S; 
		sumSdvig += before_S * after_S; 
	}
	double Co = (1000 * sumSdvig - sum * sum) / (1000 * sum2 - sum * sum); 
	printf("Correlation coefficient: %f", Co);
}

int main()
{
	conditions(); /* условия */ 
	freq();
	X_sqr(); //
	proverka_bit(); //
	correlation(); 
}
