#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <dos.h>
#include <string.h>

#define findalpha "alph_our.txt"
#define huge


float STAT[]={.0896,.0197,.04,.0153,.028,.0856,.0064,.0193,.0739,.0094,.0322,.0358,.0417,.0662,.094,.0421,.0561,.0554,.0611,.0179,.0034,.0093,.0087,.0118,.0032,.0048,.0002,.0225,.0125,.0033,.0063,.0243};

long double huge BIG[16][16][33]={0};
long double RES[32][32]={0};
long NUM=0;
int WL=0;
int fk[32]={0}; // Содержит кол-во повторений символа в подгруппе
int **F;        // It will be array with number of sumbols in each column
int marker0=1;
FILE *alpha;
FILE *target;
FILE *source;
FILE *library;
char MIX[32];
char *KEY;

void fill_MIX(FILE *f_alpha)
        {int i=0;
        while(i<32)
                {MIX[i]=fgetc(f_alpha);
                i++;}
        i=0;while(i<32){printf("%c ",MIX[i]);i++;}
        fclose(f_alpha);}

void count(FILE *source)
        {FILE *fp;
        char c;
        c=fgetc(source);
        while (c!=EOF)
                {if((c-'А')<32&&(c-'А')>=0){NUM++;}
                c=fgetc(source);}
//        fclose(fp);
        }

char get_sym()
        {char c='0';
        if(marker0)
                {while((int)c<(int)'А'||(int)c>(int)'Я')
                        {c = fgetc(source);
                        if(c==EOF) {break;}
                        }
                }
        else    {c = fgetc(source);}
        return(c);
        }

int fill_D (int *str)     //exctracting displacements between columns
        {                 //output: 1 - All Ok
        int i;            //        0 - EndOfFile
        static char c='F';
        while(0>(c-'А')||('Я'-c)<0){c=fgetc(library);if(c==EOF){return(0);}}
        i=0;while(i<WL)
                {str[i]=c-'А';
                c=fgetc(library);
                while(0>c-'А'||'Я'-c<0){c=fgetc(library);if(c==EOF){return(1);}}
                i++;}
        return(1);
        }

void fill_fk (int k,int j)
        // j - номер группы (0-6)
        // k - кол-во символов в ключевом слове
        {int i;
        char c = 0;
        i=0;while(i<32){fk[i]=0;i++;}
        fseek(source,0,SEEK_SET);
        /* Пропускаем первые j символов */
        i=0;while(i<j){c=get_sym();if(0<=(c-'А')&&0<=('Я'-c))i++;if(c==EOF)break;};
        marker0=1;
        while( c!= EOF)
                {
                c=get_sym();
                if(0<=(c-'А')&&(c-'А')<=31) {fk[c-'А']++;}
                j=1;while(j<k)
                        {c=get_sym();
                        if(0<=(c-'А')&&0<=('Я'-c))j++;
                        if(c==EOF)break;};
                }
        }

void fill_F ()
        {int i=0,j=0;
        char c;
        marker0=1;
        fseek(source,0,SEEK_SET);
        F=(int**)malloc( WL * sizeof (int*) );
                while(i<WL)
                        {F[i]=(int*)malloc(32*sizeof(int));i++;}
        i=0;while(i<WL){while(j<32){F[i][j]=0;j++;}j=0;i++;}
        i=0;j=0;
        c=get_sym();
        while( c!=EOF )
                {
                F[j][c-'А']++;
                c=get_sym();
                j++;if(j==WL){j=0;}
                i++;}
        }

void free_ALL()
        {int i=0;
        while(i<WL)
                {free(F[i]);i++;}
        free(F);
        free(KEY);
        fcloseall();}

long double pkyx(float pi,long fkj) /* рассчет Pk (Xj|Yi) */
        //pi - вероятность для норм. алфавита
        //fkj - кол-во повторений буквы в подгруппе
        {long double pk=1;
        long Nk;
        long i=0;
        Nk=(long)(NUM/WL);
        while(i<fkj)            {pk*=pi;
                                pk*=(1-pi);
                                i++;}
        while(i<(Nk-fkj))       {pk*=(1-pi);
                                i++;}
        return(pk);}

long double pkxy (int N,int J,int COL)
        // N - номер буквы (алфавитный) исходного текста (0-31)
        // J - номер буквы (алфавитный) шифра (0-31)
        // COL - номер столбца   (0-6)
        {
        int i=0;
        static int PAST=0;
        static long double EPKYX=0;
        static int J_old=0;
        if( (EPKYX==0) || (PAST!=COL) || (J!=J_old))
                {
                EPKYX=0;
                i=0;while(i<32)
                        {EPKYX+=pkyx(STAT[i],F[COL][J]);i++;}
                PAST=COL;
                J_old=J;
                }
        return (pkyx( STAT[N], F[COL][J])/EPKYX);
        }

long double pkxy2 (int N2,int J2,int COL2)
        // N - номер буквы (алфавитный) исходного текста (0-31)
        // J - номер буквы (алфавитный) шифра (0-31)
        // COL - номер столбца   (0-6)
        {
        int i=0;
        static int PAST2=0;
        static long double EPKYX2=0;
        static int J_old2=0;
        if( (EPKYX2==0) || (PAST2!=COL2) || (J2!=J_old2))
                {
                EPKYX2=0;
                i=0;while(i<32)
                        {EPKYX2+=pkyx(STAT[i],F[COL2][J2]);i++;}
                PAST2=COL2;
                J_old2=J2;
                }
        return (pkyx( STAT[N2], F[COL2][J2])/EPKYX2);
        }


double p_klr (int COL1, int COL2, int R )
        //COL1,COL2 - collumns
        //R - displacement
        {double P_KLR=1,E=0;
        int i=0,j=0;
        while(j<32)
                {
                E=0;i=0;
                while(i<32)
                        {
                        E+=pkxy(i,j,COL1)*pkxy2( ((32+i-R)%32) ,j,COL2);
                        i++;
                        }
                P_KLR*=E;
                j++;
                }
        return(P_KLR);
        }

double pklr (int COL1, int COL2, int R)
        //COL1,COL2 - collumns
        //R - displacement
        {
        int i=0;
        static int CO1=-1,CO2=0;
        static long double E=0;
        static double P_KLR[32]={0};
        if(CO1!=COL1 || CO2!=COL2)
                {E=0;
                i=0;while(i<32){P_KLR[i]=p_klr(COL1,COL2,i);i++;}
                i=0;while(i<32){E+=P_KLR[i];i++;}
                CO1=COL1;CO2=COL2;
                }
        return(P_KLR[R]/E);
        }

double fill_BIG ()
        {
        int i=0,l=0,k=0;
        printf("\n\n*** Нахождение ключевого слова ***\n\
        \nНачато заполнение массива вероятностями для возможных сдвигов\n\n");
        printf("Сейчас считаются вероятности для столбцов ");
        while(k<WL-1)
                {l=k+1;while(l<WL)
                        {printf("%d и %d",k,l);
                        i=0;while(i<32)
                                {BIG[k][l][i]=pklr(k,l,i);
                                BIG[l][k][i]=BIG[k][l][i];
                                BIG[k][l][32]+=BIG[k][l][i];
                                i++;}
//                        gotoxy(wherex()-5,wherey());
                        l++;}
                k++;}
        printf("\n\nЗаполнение завершено.\nЧтобы начать поиск слова нажмите любую кнопку...\n");
        getch();
        return(1);
        }

void get_best()
        {int k=0,l=0,i=0;
        long double BEST=0;
        long double CURRENT=0;
        int D[156];
        fill_D(D);
        do      {
                CURRENT=1;
                k=0;while(k<WL-1)
                        {l=k+1;while(l<WL)
                                {CURRENT*=BIG[k][l][(D[l]-D[k]+32)%32];
                                l++;}
                        k++;}
                if(CURRENT>BEST){BEST=CURRENT;i=0;while(i<WL){printf("%c",KEY[i]=('А'+D[i]));i++;}printf("\t%e\n\n",(double)BEST);}
                }
        while(fill_D(D));// (Пока не конец файла со словами)
        printf("\nПоследнее слово больше всего подходит для данного текста.\n\
        (рассматривались только слова из словаря)\n");
        printf("\nХотите внести изменения? ('Enter' - Да)");
        if(getch()==13)
                {printf("\nВведите слово:");scanf("%s",KEY);}

        }

float get_IS (long k,int j)
        {
        float IS=0;
        int i=0;
        /* сделаем  k  кол-вом символов в подпоследовательности */
        k=(long)(NUM-j)/k;
        i=0;
        while (i<32) {IS+= (fk[i]) * (fk[i]-1);i++;}
        return(fabs(IS/(k * (k-1))) );
        }

void find_wl()
        {int j=0,k=1,len_best=0;
        int marker1=0;
        float IS=0;
        float best=.1,temp;
        printf("\n*** Нахождение длины ключевого слова ***\n");
        printf("\nПоказать подробно? ('Enter' - Да)");
        if(getch()==13){marker1=1;}
        while(k<=16)
        {if(marker1) /*clrscr() */;
        if(marker1)printf("\n\
       [\373] - ИС попадает в интервал 0.045-0.065\n\
       распечатка ИС для длины слова %d\n",k);
        j=0;temp=0;while(j<k){
                fill_fk (k,j);
                IS=get_IS(k,j);
                if(marker1)printf("\n%.3f \t\t\tj = %d",IS,j);
                if(fabs(IS-.055)<.01){if(marker1)printf("\t[\373]");temp++;}
                else{if(fabs(IS-.055)<.015){printf("\t \367");}}
                j++;
                }
        if(best<(temp/k))
                {if(len_best==0||k%len_best){best=temp/k;len_best=k;}}
        if(marker1)getch();
        k++;
        }
        printf("\n\nБольше всего подходит длина = %d\nВведите ваш вариант:",len_best);
        scanf("%d",&WL);
        }

void encoder()
        {
        int *D;
        int i=0,j=0;
        char c;
        D=(int *)malloc(WL*sizeof(int));
        i=0;while(i<WL){D[i]=KEY[i]-'А';i++;}
        marker0=1;
        fseek(source,0,SEEK_SET);
        while((c=get_sym())!=EOF)
                {
                if((int)c>=(int)'А'&&(int)c<=(int)'Я')
                        {fputc(MIX[ (D[j]+(c-'А'))%32 ],target);}
                else    {fputc(c,target);}
                i++;
                j=i%WL;
                }
        free(D);
        printf("\nКодирование завершено.");
        }

void help(){printf("\nКурсовая работа\n\
                    \nМатематический подход к раскрытию шифров. Квадрат Вижинера.\n\
                    \nСтуденты:\t\t\tИванов Михаил, Магденко Александр, \n\t\t\t\tГурский Эдуард, Магазинов Андрей.\
                    \nПреподаватель:\t\t\tСемьянов П.В.\
                    \n\nСинтаксис:\nvigener.exe <d|e|k> <source_file> <writeto_file> <key_word> <alph_file>\
                    \n\te - Шифрует\n\td - Расшифровывает\n\tk - Декодирует\
                    \n\t<source_file> - файл с входящими данными\
                    \n\t<writeto_file> - файл для сброса результатов\
                    \n\t<key_word> - Ключевое слово (для режимов e,k)\
                    \n\t<alph_file> - файл с алфавитом\n\
                    \n\n\tПримечание: Программа работает только с большими\n\tбуквами русского алфавита\n");}


long nomer(char S)
        {int i=0;while(i<32)
                {if(S==MIX[i]){return(i);}i++;}return(-1);}

void decoder()
        {
        int *D;
        int i=0,j=0;
        char c;
        if((D=(int *)malloc(WL *sizeof(int)))==NULL){perror;}
        i=0;while(i<WL){D[i]=KEY[i]-'А';i++;}
        marker0=1;
        fseek(source,0,SEEK_SET);
        c=get_sym();
        while(c!=EOF)
                {
                if(nomer(c)==(-1)){fputc((char)('_'),target);}
                else{fputc ((char) ('А'+(nomer(c)-D[j]+32)%32),target);}
                j++;
                i++;if(!(i%77)){fputc('\n',target);}
                if(!(i%WL)){j=0;}
                c=get_sym();
                }
        free(D);
        printf("\n\nДекодирование завершено.");
        }

long double p_kxy (int N,int J)
        /* Проврено - Не лапать! */
        // N - номер буквы (алфавитный) исходного текста (без сдвига) (0-31)
        // J - номер буквы (алфавитный) шифра (0-31)
        // Возвращает вер-ть того, что J обозн-т N (абстрактные ед.)
        {
        int k=0;
        long double EPKYX=1;
        k=0;while(k<WL)
                {EPKYX*=pkyx(STAT[ (N-(KEY[k]-'А')+32) %32],F[k][J]);k++;}
        return (EPKYX);
        }

long double pkxy_a(int N, int J)
        /* N - буква нормального алфавита
           J - буква шифрованного текста
           word - ключевое слово
  Возвращает вероятность того, что J обозначает N (для данных сдвигов) (в %)
        */
        {
        int i=0;
        static long double E=0;
        static int J_old=-1;
        if(J_old!=J){
                E=0;
                i=0;while(i<32){E+=p_kxy(i,J);i++;}
                J_old=J;
                }
        return(p_kxy(N,J)/E);
        }

int getmax(int N)// N - номер (алфавитный) буквы шифра (0-31)
        {int i=0;long double swap=0;int max=0;
        while(i<32)
                {if(RES[i][N]>swap){swap=RES[i][N];max=i;}
                i++;}
        return(max);
        }

char search (int s)     // На вход давать номер буквы исходного текста
                        // Вернет номер соответсвующего символа из см. алф.
        {int i=0;
        while(i<32)
                {if(getmax(i)==s){return (i);}
                i++;}
        return(-1);}

void alphabet()
        {
        int i=0,j=0;
        char S1[32]={'А'},S2[32]={'А'};
        char swap;
        FILE *for_al;

        i=1;while(i<32){S1[i]=S1[i-1]+1;i++;}

        printf("\n\n*** Нахождение смешанного алфавита ***\n");
        printf("\nРасчет всех значений для Pk(X|Y)");
        i=0;while(i<32)
                {//fill_F();
                j=0;while(j<32){RES[j][i]=pkxy_a(j,i);j++;}
                i++;printf(".");}

        printf("\nПоказать подробно? ('Enter - Да')");
        if(getch()==13){j=0;while(j<32)
                {printf("для '%c' след-ие вер-ти по норм. алф. :\n",(char)('А'+j));
                i=0;while(i<32)
                        {printf("%c - %.2f\t\t",(char)('А'+i),100*(double)RES[i][j]);
                        if(i%2){printf("\n");}
                        i++;}
                printf("\nЛучший - '%c'",'А'+getmax(j));
                getch();
//                clrscr();
                j++;}}

        for_al=fopen(findalpha,"w");
        printf("\n");

        i=0;while(i<32){S2[i]='А'+search(i);if(search(i)==-1){S2[i]='x';}i++;}
        printf("\n\nВ результате получен алфавит (сохранен в alph_our.txt):\n\n");
        i=0;while(i<32){printf("%c ",S2[i]);i++;}
        printf("\n\n\t* Символом 'x' обозначены неизвестные буквы");
        // Сброс полученного алфавита в файл
        i=0;while(i<32){MIX[i]=S2[i];
                        fprintf(for_al,"%c",S2[i]);i++;}
        fclose(for_al);
        getch();
        }

void main(int argc, char *argv[])
{
//argv[1]  -  MODE ( d | e | k )
//argv[2]  -  TEXT
//argv[3]  -  WRITETO_FILE
//argv[4]  -  KEYWORD (if needed)
//argv[5]  -  ALPHABET

char f_al[12];
char *lib_ar[]={"0.","1.","2.","3.","4.","5.","6.","7.","8.","9.","10.","11.","12.","13.","14.","15."};
char lib[12];

if((argc<2) || (strlen(argv[1])>1)){help();exit('0');}

if((source=fopen(argv[2],"r"))==NULL){perror("\nSource file not found!");exit('5');}

target=fopen(argv[3],"w");
count(source);  /* подсчет кол-ва символов в файле */

if(argv[1][0]=='e'){
                WL=strlen(argv[4]);
                KEY=(char *)malloc(WL*sizeof(char));
                strncpy(KEY,argv[4],WL);
                strcpy(f_al,argv[5]);
                if((alpha=fopen(f_al,"r"))==NULL)
                        {printf("Файл не найден. Используется findalpha!\n");
                        getch();
                        alpha=fopen(findalpha,"r");}
                fill_MIX(alpha);
                encoder();
                }

if(argv[1][0]=='d'){
                find_wl();
                KEY=(char *)malloc(WL*sizeof(char));
                fill_F();
                strcpy(lib,lib_ar[WL]);
                printf("\nВы знаете ключевое слово? ('Enter' - Да)");
        if(getch()==13){printf("\nВведите его:");scanf("%s",KEY);}
        else{   if((library=fopen(lib,"r"))==NULL){perror("\nБиблиотека не найдена!");exit('5');}
                else{printf("\nБиблиотека подключена успешно.\n");}
                fill_BIG();
                get_best();}
                printf("\nВы знаете смешанный алфавит? ('Enter' - Да)");
        if(getch()==13)
                {printf("\nВведите имя файла содержащего алфавит:");
                scanf("%s",f_al);
                if((alpha=fopen(f_al,"r"))==NULL)
                        {printf("\nФайл не найден. Будем искать алфавит сами.");
                        alphabet();
                        }
                fill_MIX(alpha);
                }
        else{alphabet();}
                decoder();
                }

if(argv[1][0]=='k'){
                WL=strlen(argv[4]);
                KEY=(char *)malloc(WL*sizeof(char));
                strncpy(KEY,argv[4],WL);
                strcpy(f_al,argv[5]);
                if((alpha=fopen(f_al,"r"))==NULL)
                        {printf("Файл не найден. Используется findalpha!\n");
                        getch();
                        alpha=fopen(findalpha,"r");}
                fill_MIX(alpha);
                decoder();
                }
}

