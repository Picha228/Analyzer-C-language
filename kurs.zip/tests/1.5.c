int chipher_choice() {
	long length = strlen(string);

	if (!strncmp("aes", string, length)) *chipher_mode = 1;
	else if (!strncmp("kuznechik", string, length)) *chipher_mode = 2;

}

void invalid_usage_crypt_decrypt(void) {
	
	printf("Invalid usage \'-c\' and \'-d\' together\n");
        printf("Process was interrupted!\n");
        printf("Enter \"-h\" or \"--help\" for instruction\n\n");
	exit(0);

}

int main(int argc, char ** argv) {
	
	short chipher_mode;
	short crypt_or_decrypt = 0; // if 'crypt' -> 2, else -> 1

	_Bool gui_or_terminal = 0; // if 'gui' -> 1, else -> 0
	_Bool stego_mode = 0; // if 'hide' -> 0, else if 'seizure' -> 1
	_Bool sourcefile_flag = 0;
	_Bool messagefile_flag = 0;
	_Bool hex_or_decimal = 0; // if '1' -> hex, '0' -> decimal

	unsigned char way_to_resultfile[64] = { '\0' };	
	unsigned char way_to_sourcefile[64] = { '\0' };
	unsigned char way_to_messagefile[64] = { '\0' };
	
	unsigned char * message;
	size_t message_size = 0;
	FILE * fstream;

	if (argc <= 1) {
		system("cat canary_info");
		return 0;
	}

	else {
		for (int counter = 1; counter < argc; ++counter) {

			long length_of_argument = strlen(argv[counter]);

			if (!strncmp("-e", argv[counter], strlen(argv[counter]))) {

				if (crypt_or_decrypt == 1) {
					invalid_usage_crypt_decrypt();	
				}
				crypt_or_decrypt = 2;
				++counter;
				if (counter == argc) {
					printf("Error. No information of chipher!\n");
					exit(0);
				}
				chipher_choice(argv[counter], &chipher_mode);
			}

			else if (!strncmp("-d", argv[counter], strlen(argv[counter]))) {
				
				if (crypt_or_decrypt == 2) {
					invalid_usage_crypt_decrypt();
				}

				crypt_or_decrypt = 1;
				++counter;
				if (counter == argc) {
					printf("Error. No informarion of chipher!\n");
					exit(0);
				}
				chipher_choice(argv[counter], &chipher_mode);

                        }

			else if (!strncmp("-s", argv[counter], strlen(argv[counter]))) {
				++counter;
				if (counter == argc) {
					printf("Error. No way to file!\n");
					exit(0);
				}
				get_way_to_file("-s", argv[counter], way_to_sourcefile);
				sourcefile_flag = 1;
			}

			else if (!strncmp("-m", argv[counter], strlen(argv[counter]))) {
				++counter;
				if (counter == argc) {
					printf("Error. No way to file!\n");
					exit(0);
				}
				get_way_to_file("-m", argv[counter], way_to_messagefile);
				messagefile_flag = 1;
			}

			else if (!strncmp("-r", argv[counter], strlen(argv[counter]))) {
				++counter;
				if (counter == argc) {
					printf("Error. No way to file!\n");
					exit(0);
				}
				get_way_to_file("-r", argv[counter], way_to_resultfile);
                        }

			else if (!strncmp("-h", argv[counter], strlen(argv[counter]))) {
				system("cat canary_info");
				return 0;
			}

			else if (!strncmp("--help", argv[counter], strlen(argv[counter]))) {
				system("cat canary_info");
				return 0;
			}
			
			else if (!strncmp("-hex", argv[counter], strlen(argv[counter]))) {
				hex_or_decimal = 1;
			}

			else if (!strncmp("-gui", argv[counter], strlen(argv[counter]))) {
				gui_or_terminal = 1;
			}
			else if (!strncmp("--extract", argv[counter], strlen(argv[counter]))) {
				stego_mode = 1;
			}

			else {
				printf("\nInvalid argument!\n");
				printf("Enter \"canary -h\" for instruction\n\n");
				return 0;
			}

		}
	}

	if (stego_mode == 0 && crypt_or_decrypt == 1) {
		printf("You are turning on decrypt-mode and hide-mode.\n");
		printf("Process is interrupted!\n");
		printf("Enter \"--help\" or \"-h\" for instruction!\n");
                exit(0);
	}

	if (stego_mode == 0 && way_to_resultfile[0] == 0) {
		printf("No information of result file. Process is interrupted!\n");
		printf("Enter \"--help\" or \"-h\" for instruction!\n");
		exit(0);
	}

	if (!sourcefile_flag) {
		printf("No information of source file. Process is interrupted!\n");
		printf("Enter \"--help\" or \"-h\" for instruction!\n");
		exit(0);
	}
	if (!messagefile_flag && stego_mode != 1) {
		printf("No information of file with message. Process is interrupted!\n");
                printf("Enter \"--help\" or \"-h\" for instruction!\n");
                exit(0);
	}
	
	if (stego_mode) {
		
		size_t finish_count = 0, counter = 0;
		size_t quantity = get_quantity_bytes(way_to_sourcefile, &finish_count, &counter);

		message = (unsigned char *)calloc(quantity, sizeof(unsigned char));
		message_size = quantity;
		
		stego(message, &message_size, way_to_sourcefile, way_to_resultfile, stego_mode, finish_count, counter);
		if (crypt_or_decrypt) crypto(crypt_or_decrypt, message, chipher_mode, message_size);
		build_decryptfile(message, way_to_resultfile, message_size, hex_or_decimal);

		printf("\nProcess is finishing!\n");
	       	if (way_to_resultfile[0] != 0) printf("Message saved in file %s!\n", way_to_resultfile);

	}	
	else {
        	fstream = fopen(way_to_messagefile, "r");
       		get_file_size(&fstream, &message_size);
		
		int part = 0;
	       	if (message_size % 16) {
			part = 16 - (message_size - message_size / 16 * 16) % 16;
		}

        	message = (unsigned char *)calloc(sizeof(unsigned char), message_size + part);

		if (part) {
		       for (size_t i = message_size; i < message_size + part - 1; ++i) {	
				message[i] = 0x00;
		       }
		       message[message_size + part - 1] = 0x01;
		}
		message_size += part;
        	
		fread(message, sizeof(char), message_size, fstream);

		if (crypt_or_decrypt) {
			crypto(crypt_or_decrypt, message, chipher_mode, message_size);
		}
		stego(message, &message_size, way_to_sourcefile, way_to_resultfile, stego_mode, 0, 0);

		free(message);
		fclose(fstream);		
	}

	return 0;
}
